# BT5 report kiosk — user guide

**Attendees beam their progress to a kiosk saber, and a TV shows who's
winning.** This guide is for the organizers who set that up and keep it
running. For how it works inside, see
[docs/report-kiosk.md](../docs/report-kiosk.md).

```
attendee saber ──IR──▶ kiosk saber ──USB debug probe──▶ kiosk-host ──network──▶ TV  +  kiosk terminal
```

| Piece | What it is |
|---|---|
| **kiosk saber** | A normal badge running the *kiosk* firmware. It receives reports over IR, checks each one is genuine, and keeps them in memory. |
| **debug probe** | The Raspberry Pi debugprobe clipped to the kiosk saber's dev pins. It's how the computer reads the saber. |
| **kiosk-host** | A program on the computer the probe is plugged into. It reads reports off the saber, saves them, and serves the leaderboard web page. |
| **TV / projector** | A browser showing the standings for the room. |
| **kiosk terminal** | A monitor, keyboard and mouse where attendees look themselves up. |

- Setting up: [What you need](#what-you-need) · [Setting up](#setting-up)
- On the day: [Running it](#running-it) · [The pages](#the-pages) · [URL reference](#url-reference)
- Reference: [Scoring](#scoring-and-ranking) · [Options](#command-line-options) · [The data file](#the-data-file)
- When things go wrong: [Troubleshooting](#troubleshooting)

---

# What you need

- **The kiosk saber**, flashed with the kiosk firmware (see
  [Flash the kiosk saber](#1-flash-the-kiosk-saber)). Keep it with
  organizers: it can check every badge's signature.
- **A debugprobe** and its cable to the saber's dev pins.
- **Power for the saber that lasts the day.** Use the dock or a bench
  supply, not AA batteries.
- **The host computer:** x86_64 Linux with systemd (Ubuntu 22.04+, Debian
  12+), or a Raspberry Pi 4/5 with 64-bit Raspberry Pi OS. It doesn't need
  Rust or probe-rs. A Pi with a screen attached can be the whole kiosk:
  see [Boot straight into the kiosk](#boot-straight-into-the-kiosk).
- **Browsers for the TV and the terminal.** They can run on the host
  computer or on other machines that can reach it on port 8080. Chromium is
  assumed below.
- **Optional:** internet access on the browser machines, for the page font.
  Without it the page uses the system's monospace font and otherwise looks
  the same.

---

# Setting up

Do this once, before the event.

## 1. Flash the kiosk saber

On a development machine with the repo and a probe:

```sh
cd saber-fw
cargo run --features kiosk,admin
```

(`admin` builds in the con's master key. Without it the kiosk reads its key
from flash, and shows a solid red blade if there isn't one: see
`bt5-badge kiosk-key`.)

Check that it worked:
- The saber's screen shows the BLACKTUQUE 5 splash: the noda, the logo, a
  saber, and **AIM SABER HERE** along the bottom.
- The log prints `kiosk mode: collecting progress reports (per-report ids)`.

Press Ctrl-C when done. The firmware stays on the saber.

> Every attendee saber must be flashed from the same code. A saber with
> older firmware can still report, but pressing Push twice in a row only
> counts once.

## 2. Build the host program

On the development machine:

```sh
cd kiosk-host
./make-release.sh --native
```

This makes `dist/kiosk-host-<target>.tar.gz`. Copy it to the host computer.
Use plain `./make-release.sh` instead if the host computer is a Raspberry
Pi or runs an older Linux: it builds both an x86_64 and an aarch64 (64-bit
Pi OS) tarball, and needs `cargo-zigbuild` and `zig`.

## 3. Install it on the host computer

```sh
tar xzf kiosk-host-*.tar.gz
cd kiosk-host-*/
sudo cp 69-bt5-debugprobe.rules /etc/udev/rules.d/
sudo udevadm control --reload-rules && sudo udevadm trigger
```

Unplug and replug the probe. Without this rule, only root can use the probe.

If the TV or terminal browser runs on a different machine, open the port:

```sh
sudo ufw allow 8080/tcp      # if ufw is enabled
```

## Boot straight into the kiosk

On a machine that does nothing else, such as a Raspberry Pi behind the TV,
the installer in the tarball sets everything up so that the kiosk starts on
power-up with no one logging in:

```sh
tar xzf kiosk-host-aarch64-*.tar.gz
cd kiosk-host-aarch64-*/
sudo ./install.sh                     # the screen shows /pi?rotate on a Pi, /?rotate elsewhere
sudo ./install.sh --page '/pi?kiosk'  # ...or the attendee terminal instead
sudo reboot
```

It installs the probe rule from step 3 for you, and:
- Runs kiosk-host as the service `bt5-kiosk-host`, restarting it if it
  stops. It uses whichever probe is plugged in. If more than one is, set
  `KIOSK_HOST_ARGS=--probe 2e8a:000c:SERIAL` in the settings file.
- Shows the page full-screen on the attached display with Chromium in
  [cage](https://github.com/cage-kiosk/cage), as the service
  `bt5-kiosk-browser`. It installs both with `apt` if they're missing, so the
  first run needs internet access.
- Turns off the desktop login screen if there is one, since the kiosk takes
  over the display. `--uninstall` turns it back on.
- Keeps the mouse pointer off the TV pages, even with a mouse plugged in
  (the attendee terminal keeps it). Chromium only hides it once the pointer
  moves, so for the first minute the service parks it in the bottom-right
  corner through a short-lived virtual mouse
  (`/opt/bt5-kiosk/nudge-pointer.py`).

| What | Where |
|---|---|
| Settings: which page, the port, extra kiosk-host options | `/etc/default/bt5-kiosk`, then `sudo systemctl restart bt5-kiosk-host bt5-kiosk-browser` |
| Who counts as a winner | `/etc/bt5-kiosk/winners.toml` — takes effect when saved, no restart (see [Winners](#winners)) |
| What each thing scores | `/etc/bt5-kiosk/scoring.toml` — takes effect when saved, no restart (see [Scoring](#scoring-and-ranking)) |
| The data file | `/var/lib/bt5-kiosk/leaderboard.json` |
| Merge in another kiosk's board | `sudo bt5-merge-in other-site.json` (see [Merging two kiosks](#merging-two-kiosks)) |
| Clear the board (test data, before the con) | `sudo systemctl start bt5-kiosk-reset` (see [Starting a fresh leaderboard](#starting-a-fresh-leaderboard)) |
| kiosk-host's output | `journalctl -fu bt5-kiosk-host` |
| Stop / start collecting | `sudo systemctl stop bt5-kiosk-host` / `start` |

To upgrade, run `sudo ./install.sh` from the new tarball; your settings and
data are kept. `sudo ./install.sh --headless` installs only kiosk-host, for a
machine with no screen. `sudo ./install.sh --uninstall` removes the
services but keeps the data.

To get a shell on the Pi while the kiosk runs, use SSH or switch to another
console with Ctrl+Alt+F2.

## A laptop with a projector (offline, locked down)

An Ubuntu laptop can run the whole kiosk with no network: the attendee
terminal (`/?kiosk`) on its own screen, the rotating board on a projector,
and no way out for attendees but a password-gated admin terminal
(**Ctrl+Alt+Shift+T**). It has its own manual, **`laptop-manual.md`** in the
tarball: its packages must be installed while the laptop still has a
network, so read "Before you go offline" first. In short:

```sh
./install.sh --laptop --check       # lists anything missing, with the apt command
sudo ./install.sh --laptop          # asks which output is the laptop screen / projector
sudo reboot
```

## 4. Do a dry run

1. Plug the probe into the host computer and the kiosk saber.
2. Start `./kiosk-host --probe 2e8a:000c` and wait for
   `attached; kiosk log at 0x20000064`.
3. Open <http://localhost:8080> in a browser.
4. Report from a test saber (see [What attendees do](#what-attendees-do)).
   Its row appears within a second.

---

# Running it

## Start order

1. **Power the kiosk saber** and connect the probe.
2. **Start kiosk-host** from a folder that will hold the day's data:
   ```sh
   ./kiosk-host --probe 2e8a:000c
   ```
   It prints:
   ```
   leaderboard on http://0.0.0.0:8080  (db: leaderboard.json)
   attached; kiosk log at 0x20000064
   ```
   Leave it running. Each report page that arrives prints a line such as
   `badge 1111 page 0 -> "LUKE" [ATTENDEE] challenges=0x00000401 W3-L2 (talks 4/14, ...)`.
   The part in brackets at the end is the winner verdict (`winner`, or what
   is still missing); it is only printed here.
3. **Start the TV browser:**
   ```sh
   chromium --kiosk --noerrdialogs http://HOST:8080/?rotate
   ```
4. **Start the terminal browser:**
   ```sh
   chromium --kiosk --noerrdialogs http://HOST:8080/?kiosk
   ```

Replace `HOST` with the host computer's address, or `localhost` if the
browser runs on the same machine. `--kiosk` hides the address bar and tabs;
Alt+F4 quits.

## What attendees do

1. On their saber, go to the **Record** tile. From the home screen, press
   **Up** twice.
2. Press **Push** to open the Service Record.
3. Press **Push** again. The screen shows **REPORT / SENDING** for about 7½
   seconds, and longer for someone who has been to a lot of talks. The saber
   sends its list of talks too, which adds about 1½ seconds per 40 talk slots
   it uses. That's around 13 seconds by the end of the con.
4. Aim the blade tip at the kiosk saber until it shows **SENT**.

The kiosk saber chimes and flashes when the whole report has arrived. The
report shows up on the TV within about a second.

Attendees can report as often as they like; each report replaces the last
one for that saber. Nothing on the attendee's saber changes when it
reports.

## The kiosk saber's screen

| What you see | Meaning |
|---|---|
| **BLACKTUQUE 5 splash / AIM SABER HERE** | Idle. Nothing has arrived for 30 seconds, or since boot or the last Push. |
| **Handle, `#1111` and rank** | The saber reporting now, in the bracketed card at the top. |
| **Ring of dots around `3/12`** | Challenges done: one lit dot per challenge. The faint crest behind it is the saber's side. |
| **`W` / `L`** | Battles won and lost. |
| **Saber along the bottom, and a percent** | How much of the report has arrived. It fills with the kiosk's blade. |
| **RECEIVED, chime and blade flash** | Every part arrived; the report is complete. |

The last report stays up for 30 seconds after its final part arrives, then
the screen goes back to the splash.

Press **Push** on the kiosk saber to go back to the splash right away. That
doesn't delete anything.

Usually the saber fills steadily and the chime follows. If it stops short,
the attendee should keep aiming: each part is sent 3 times.

## Stopping and restarting

- **Stop kiosk-host** with Ctrl-C. Everything received is already saved in
  `leaderboard.json`.
- **Restart it** from the same folder; it picks up where it left off,
  including reports the kiosk saber received while it was stopped. The
  saber keeps the last 1024 report parts, about 256 reports.
- **Unplugging the probe** or restarting the kiosk saber is fine;
  kiosk-host retries every 2 seconds.
- **Reports sent while the kiosk saber is off are lost.** The attendee has
  to report again.

---

# The pages

All the pages show the same data, split into two columns: the **Galactic
Empire** and the **Rebel Alliance**. Each column has the faction's logo,
its total score and its member count, and ranks its members by score.

Every row shows:

| Column | Meaning |
|---|---|
| **#** | Rank within the faction. The leader's row is highlighted. |
| **Operative** | Handle and badge id. `UNNAMED` means the attendee never set a handle. `[partial]` means part of their report hasn't arrived yet, so some numbers may be missing. Staff sabers also carry a **DEV**, **BOUNCER** or **SPEAKER** tag, and some rows carry marks — see below. |
| **Rank** | The saber's rank title, climbed by completing challenges *and* leaning further toward the faction (see below). |
| **Challenges** | A bar and `done/total`, counting the challenges on the saber's menu. |
| **W-L** | Battle wins and losses. |
| **Talks** | Talks attended. |
| **Droids** | Different allegiance droids the saber has reported to either side. Droid Finder beacons don't count here; finishing that hunt is a challenge. |
| **Reports** | Allegiance droid reports filed in total, to either side. A droid can be reported again each time it rotates its epoch. |
| **Score** | See [Scoring](#scoring-and-ranking). |

**UNALIGNED** below the columns lists sabers with no faction yet, and
sabers whose faction part of the report hasn't arrived. A saber only
reports a faction once it leans at least 6 droid reports toward one side,
so a lightly tinted blade still shows up here.

**Rank titles.** Each faction has its own ladder, lowest first:

| Tier | Empire | Rebel | Unaligned |
|---|---|---|---|
| 0 | ACOLYTE | INITIATE | WANDERER |
| 1 | APPRENTICE | PADAWAN | SCOUT |
| 2 | WARRIOR | KNIGHT | RANGER |
| 3 | LORD | MASTER | ADEPT |
| 4 | DARTH | GRAND MASTER | GRAY |

Tier 1 needs one challenge. Tier 2 needs 2 challenges and a lean of 4, tier
3 needs 4 challenges and a lean of 8, and tier 4 needs every challenge and a
lean of 12. The board names the rank from the ladder of the side it lists
the saber under, so an unaligned saber shows an unaligned title even if its
blade has started to tint. The unaligned strip shows the title after the
badge id.

The small violet marks after some handles — **◆ ▲ ● ■** — are one per kind
of saber that operative has beaten in a duel: an attendee, a DEV, a bouncer
and a speaker, in that order. All four is the "defeated one of each" goal.
The page says none of this on purpose, so please don't explain the marks to
attendees — working them out is part of the game.

## Winners

A gold **WINNERS** panel runs across the top of every page, above the two
faction columns. It lists every saber that has won the badge, ranked by
score the same way the factions are, and shows **WON**: the day and time of
the report that first met the rule (the kiosk machine's clock). Until
someone wins it is a single line, *no one has won the badge yet*. Winners
also stay in their faction's column, marked with a gold **★**.

**The rule is secret.** Neither the pages nor the JSON feed say what it
takes to win — only who has. Keep it that way when talking to attendees.
By default a saber has won when its report shows all of:

- every challenge on the saber's menu complete
- 14 talks attended, in at least 2 different tracks (rooms)
- reports to 6 different allegiance droids
- a lean of at least 12 droid reports toward one side
- 10 more battle wins than losses

"Every challenge" means the ones on the saber's menu. The hidden challenge
(not on the menu, and never mentioned to attendees) only counts if
`hidden = true` is set: then a winner needs it as well.

**Changing the rule.** Edit `/etc/bt5-kiosk/winners.toml` (or `winners.toml`
next to kiosk-host when running it by hand, or pass `--winners FILE`). Each
line is explained in the file. Save it and the pages pick it up within a
few seconds — no restart. If the edit has a mistake (a misspelt key, a bad
value), kiosk-host keeps the old rule and says why in its output
(`journalctl -fu bt5-kiosk-host`).

**Who is on the board, and who can win.** The same file has four more
settings, all off by default:

| Setting | Effect |
|---|---|
| `hide_admin = true` | Sabers running an admin firmware build (organizer hardware) are left off the board entirely. |
| `hide_roles = ["DEV"]` | Sabers of these roles are left off the board entirely. |
| `no_win_roles = ["DEV", "BOUNCER"]` | Sabers of these roles rank on the board as usual but never win. |
| `hide_winners = true` | Nobody shows as a winner yet: the panel says *no one has won the badge yet*, no ★, no winner banner on profiles. `/admin` still counts them. |

Roles are named as the board shows them: `ATTENDEE`, `DEV`, `BOUNCER`,
`SPEAKER`. A saber is only hidden once the part of its report carrying its
role or admin flag has arrived. The console says `role can't win` for a saber
held back by `no_win_roles`.

Loosening the rule mid-event is fair to everyone: kiosk-host keeps every
report a saber has sent, with its time, and a winner's **WON** time is the
first of them that meets the rule now in force.

**Revealing winners later.** Set `hide_winners = true` before the con, then
watch **Winners** and **Winners by day** on `/admin` to judge whether the rule
is too hard or too easy, and retune it. When you are ready, set it back to
`false`: everyone who has met the rule appears at once, each with the time
they actually won. The console keeps printing `winner` either way.

On the TV pages the panel shows the top 5 winners (3 on `/pi`) and
**+N more winners**; `/?rotate` pages through them with the columns.

## Suspected cheaters

A small red-labelled strip near the bottom, **SUSPECTED CHEATERS**, lists
sabers that have at some point started up with a save that failed its
integrity check — what happens when someone edits their saber's memory to
change its progress. The saber wiped its progress when that happened and
remembers it from then on; its report says so. The saber still ranks and can
still win: the strip names it, it doesn't disqualify it.

It is a suspicion, not proof. A battery pulled at the exact moment the saber
saves can damage the save the same way. Talk to the owner before acting on
it. An organizer **neuralyze** clears the record along with everything else,
which is also how a saber is handed to a new owner. `tools/show_state.sh`
shows the record as `tamper seen`.

The top line shows:
- **`[ UPLINK OK ]`**: the whole chain is working — the browser is reaching
  kiosk-host, and kiosk-host is reading the kiosk saber. It turns red as
  **`[ UPLINK LOST ]`** if either half breaks; the terminal says which (see
  [Troubleshooting](#the-page-says-uplink-lost)). Under `--no-probe` it reads
  **`[ OFFLINE BOARD ]`** in grey, because there is no saber to lose.
- The number of operatives on the board.
- **`sync`** with the time of the last update. The page updates every 3
  seconds without reloading.

## The TV pages

### `/` — top of each faction

Each column shows as many top-ranked rows as fit the screen, followed by
**+N more operatives**. The row count adjusts to the TV's resolution and
whenever the window is resized.

### `/?rotate` — every rank, in turns

Each column starts with the same top rows, then every **10 seconds** shows
the next group down. Beside the member count, **page 2/17** says where each
column is, and **ranks 12–22 of 183** appears underneath. After the last
group it starts again from the top. The two columns page independently, so
a smaller faction wraps around sooner.

**Use `/?rotate` for the room.** With `/`, only the leaders are ever seen.

Both TV pages:
- Show the footer **"find your rank at the kiosk terminal"**.
- Let the unaligned strip use whatever screen the columns leave, and trim
  it to two lines (one on `/pi`) of whole sabers when there is none.
  `/` ends it with **+N more**; `/?rotate` pages through the rest with the
  columns (**8–14 of 40**).
- Stack the columns and show 10 rows each on a screen narrower than 900
  pixels. Use a full-HD or larger display.

## The kiosk terminal — `/?kiosk`

The terminal shows **every** operative, so attendees can scroll with the
mouse wheel. The header stays pinned at the top, with a **find>** box:

- **The box always has the cursor.** An attendee can walk up and type; a
  click anywhere puts the cursor back.
- **Type a badge id** (`1111` or `#1111`) to open that saber's **profile**
  in place of the standings, as soon as the 4th digit is in. The id is shown
  on the saber's home screen and on its Battle page.
- **Or type part of a handle**, 2 letters or more. Matches turn gold as you
  type and the page scrolls to the first one; **Enter** opens the profile
  when exactly one saber matches (or on a short id such as `#42`), and
  otherwise jumps back to the first match.
- The status line says **found LUKE #1111**, **3 operatives match "LU"**, or
  **no operative matches "XYZ" yet** (not reported, or a typo).
- **Esc** clears the search, closes a profile and returns to the top.
- **After 60 seconds** with no typing, scrolling or mouse movement, the page
  clears itself for the next person.

The profile is that saber's report laid out for its owner, in panels like
`tools/show_state.sh`'s printout: handle, role, faction and rank title, score
and where it places (overall and in the faction), duels, the menu's
challenges ticked off, the score taken apart line by line, the talks
attended room by room (with titles from [talks.toml](#talk-titles) and the
back-to-back ones marked), droids and allegiance lean, and when the kiosk
heard from it. A winner gets a gold banner with the time they won; a
suspected cheater gets a note. It refreshes with the board, so a report
pushed while it is up appears on it.

What it deliberately leaves out, so the terminal gives no challenge away:
hidden challenges (done or not), the ◆ ▲ ● ■ marks and which roles earned
them, and anything about the winner rule, including how close the saber is.
These are left out by the host, not just by the page: `/api/profile` never
sends them.

## Organizer stats — `/admin`

A page for organizers, not the TV. It refreshes every 30 seconds.

- **Headline numbers:** participants, badges active in the last hour and
  day, reports synced, average challenges per badge, talk credits, duels
  won, winners and suspects. The winners tile says *hidden from the board*
  while `hide_winners` is on.
- **Winners by day:** how many sabers first met the rule each day, the
  running total, and the first and last win that day.
- **Trends:** participants, average challenges, reports per hour, talk
  credits, challenge completions and winners over the con, one chart each.
  Hovering over one chart marks the same hour on all six, and
  **Timeline as a table** lists the numbers behind them.
- **Progress:** how many badges have finished each challenge, and how many
  have finished 0, 1, 2… of them.
- **Talks:** the most attended talks, attendance at every talk room by room
  in schedule order (and as a table), badges that sat a talk in each room,
  badges by number of talks, and the top 5 talk-goers.
- **Who's playing:** factions and roles. **Leaders:** most duels, most
  reports, droid reports.

What it counts:

- It counts only the badges the leaderboard shows. Badges hidden by
  `hide_admin` or `hide_roles` in `winners.toml` are left out, so organizer
  hardware doesn't inflate the numbers. The Participants tile says how many
  were hidden.
- A time on this page is when the kiosk **received** a report. A challenge
  finished on Friday and first reported on Saturday counts as Saturday's.
- Per-talk attendance comes from the talk list each saber sends with its
  report. It's as of each saber's latest report, so a talk's count grows as
  people come to the kiosk. A talk's percentage is of the sabers that sent a
  talk list.
- Sabers on firmware from before talk lists count their talks but don't name
  them. The page says how many there are. Their talks are in the totals but
  not in any one talk's attendance.
- Like the TV pages, it never says what winning takes.

The page has no password. Anyone on the kiosk's network who knows the
address can open it.

### Talk titles

Out of the box, talks show as their room and number, such as **Room 1 · #4**.
To show titles, list them in `talks.toml`. The installer puts the file at
`/etc/bt5-kiosk/talks.toml`; when running kiosk-host by hand, it's
`talks.toml` in the current folder (or pass `--talks FILE`).

```toml
[rooms]
1 = "Main Hall"
2 = "Hangar Bay"

[talks.1]
0 = "Opening keynote"
1 = "Thermal exhaust ports: a post-mortem"

[talks.2]
0 = "IR for the rest of us"
```

- A talk's number is the one its room's remote gave it: 0 for the first
  talk the emcee credited in that room, then 1, 2, 3… in the order they
  were credited. If an emcee forgets to credit a talk, the numbers after it
  shift down by one, so check the list against what the emcees did.
- Every entry is optional. Anything not listed shows as room and number.
- A titled talk nobody has reported yet shows with 0 badges, so a talk that
  was never credited stands out.
- Save the file and the page shows the change on its next refresh, with no
  restart. If the file has a mistake (a room outside 1–4, a number outside
  0–127, a misspelt table), kiosk-host keeps the titles it had and prints why
  in its terminal (`journalctl -u bt5-kiosk-host`). At startup, a broken
  file stops kiosk-host.

---

# URL reference

`HOST` is the host computer's address; the port is 8080 unless you changed
[`--listen`](#command-line-options).

| URL | Use it for | What it shows |
|---|---|---|
| `http://HOST:8080/` | TV | Top rows of each faction that fit the screen, then **+N more operatives**. |
| `http://HOST:8080/?rotate` | TV (recommended) | Pages each faction's full ranking, 10 seconds per page. |
| `http://HOST:8080/?kiosk` | Kiosk terminal | Every operative, with the **find>** lookup box; a badge id opens that saber's profile. |
| `http://HOST:8080/pi?rotate`, `/pi?kiosk`, `/pi` | A Raspberry Pi screen | The same pages in a lite layout: no animation, blur or glow (a Pi flickers on them), and sized for a small 1024×600 panel, where the full page fits only 3 rows a column and cuts off the score. To leave room for handles, the challenges column is the bar alone (no `9/13`; hover for it) and Talks, Droids and Reports are headed **T**, **D** and **R**. `/pi` goes in front of any of the other options. |
| `http://HOST:8080/?all` | Checking the full board | Every operative, no lookup box. |
| `http://HOST:8080/?badge=1111` | Linking to one saber | Every operative, with badge 1111 highlighted and scrolled into view. |
| `http://HOST:8080/?kiosk&q=LUKE` | Testing the terminal | The terminal, with **LUKE** already typed in (`q=1111` opens that profile). `q=` works with `?all` too. |
| `http://HOST:8080/admin` | Organizers | [Stats and trends](#organizer-stats--admin): participants, progress, talks, leaders. |
| `http://HOST:8080/api/leaderboard` | Scripts, backups, your own displays | The whole board as JSON (below). |
| `http://HOST:8080/api/profile?id=1111` | The kiosk terminal's profiles | One saber, as the [profile](#the-kiosk-terminal--kiosk) shows it, or *not found* for a saber the board doesn't show. Carries none of the hidden challenges, marks or winner-rule progress. |
| `http://HOST:8080/api/stats` | Scripts | The numbers behind `/admin`, as JSON. |
| `http://HOST:8080/api/status` | Checking the saber link from a script | Whether the probe is collecting: `{"state":"ok"}`, or `"lost"` with the probe error in `detail`, or `"off"` under `--no-probe`. |
| `http://HOST:8080/assets/empire.png`, `/assets/rebel.png` | Other graphics | The faction logos, white on transparent. |

Anything else returns *not found*. Only the part before `?` picks the page,
so `/?rotate&anything=else` still works.

## The JSON feed

`/api/leaderboard` returns every saber as a list, highest score first:

```json
[
  {
    "rank": 1,
    "badge_id": "1111",
    "handle": "LUKE",
    "challenges": 5,
    "challenges_total": 12,
    "wins": 3,
    "losses": 2,
    "talks": 4,
    "droids": 2,
    "droid_reports": 6,
    "faction": "Republic",
    "title": "KNIGHT",
    "role": "ATTENDEE",
    "marks": 5,
    "score": 740,
    "complete": true,
    "last_seen": 1789430000,
    "reports": 3,
    "reported_at": 1789429990,
    "winner": false,
    "won_at": null
  }
]
```

| Field | Meaning |
|---|---|
| `rank` | Overall rank across both factions. The pages rank within each faction instead. |
| `badge_id` | 4 hex digits. |
| `handle` | May be empty. |
| `challenges` / `challenges_total` | Challenges done, out of those on the saber's menu. |
| `wins`, `losses`, `talks`, `droids`, `droid_reports` | As on the page. `droids` is the Droids column and `droid_reports` the Reports column. |
| `faction` | `Empire`, `Republic`, `Neutral`, or `?` if that part of the report hasn't arrived. |
| `role` | The saber's own role: `ATTENDEE`, `DEV`, `BOUNCER`, `SPEAKER`, or empty if that part of the report hasn't arrived. Self-reported — see below. |
| `marks` | Bitmask behind the ◆ ▲ ● ■ marks: bit 0 attendee, 1 DEV, 2 bouncer, 3 speaker. Named vaguely so the feed doesn't explain the puzzle either. |
| `score` | See [Scoring](#scoring-and-ranking). |
| `complete` | Every part of the report has arrived at some point: the 5 fixed parts, and each part of the talk list the saber said it would send. |
| `last_seen` | Unix time kiosk-host last received anything from this saber. |
| `reports`, `reported_at` | How many reports the saber has sent, and the Unix time of the latest. |
| `winner`, `won_at` | Meets the [winner rule](#winners), and the Unix time of the first report that did. The rule itself is not in the feed. |
| `suspect` | Listed under [suspected cheaters](#suspected-cheaters). |

`role` is signed by the saber, so nobody can claim a role on someone else's
badge — but it is the saber's own word about itself, exactly like every
other number here. An attendee who extracts their own saber's secret can
report whatever they like about themselves. It is a name on a leaderboard,
not an access check: nothing the DEV badge can actually do is gated on it
(that is `identity::is_organizer`, on the badge, which this never touches).

---

# Scoring and ranking

| Earns | Points |
|---|---|
| Each challenge done | 100 |
| Each battle win | 10 |
| Each talk attended | 20 |
| Each talk attended back to back (see below) | 20 × 1.5 = 30 |
| Each different allegiance droid reported | 50 |
| Each allegiance droid report | 5 |

Losses cost nothing. Ties are broken by more challenges, then by the lower
badge id. The faction score is the sum of its members' scores.

**Back-to-back talks.** A talk scores extra when the saber also sat the talk
before it in the same room: three talks in a row in one room earn
20 + 30 + 30. "Before it" goes by the numbers the room's remote gives its
talks, so a talk the emcee forgot to credit breaks the run. Talks in
different rooms never count as back to back, because the report doesn't say
when each talk was. Sabers on firmware from before talk lists (see
[Organizer stats](#organizer-stats--admin)) get no bonus, and a saber whose
talk list is still missing a part gets the bonus only for the talks that
have arrived.

The numbers come from the saber's own records at the moment it reports, so
a saber's row only changes when it reports again.

**Changing the scoring.** Edit `/etc/bt5-kiosk/scoring.toml` (or
`scoring.toml` next to kiosk-host when running it by hand, or pass
`--scoring FILE`). Each value in the table above has a line there, and
`back_to_back` is the multiplier (1 turns the bonus off). Save it and every
saber is re-scored on the next page refresh — no restart. If the edit has a
mistake, kiosk-host keeps the old scoring and says why in its output
(`journalctl -fu bt5-kiosk-host`).

---

# Command-line options

```
./kiosk-host [OPTIONS]
```

| Option | Default | Meaning |
|---|---|---|
| `--probe VID:PID[:SERIAL]` | the only probe attached | Which probe to use. The debugprobe is `2e8a:000c`. Required if more than one probe is plugged in. |
| `--db FILE` | `leaderboard.json` | Where results are saved, relative to the current folder. |
| `--winners FILE` | `winners.toml` | The winner rule (see [Winners](#winners)). Missing means the default rule. Re-read whenever it is saved. |
| `--scoring FILE` | `scoring.toml` | Points per challenge, win, talk and droid, and the back-to-back multiplier (see [Scoring](#scoring-and-ranking)). Missing means the default scoring. Re-read whenever it is saved. |
| `--talks FILE` | `talks.toml` | Talk titles and room names for `/admin` and the terminal's profiles (see [Talk titles](#talk-titles)). Missing means talks show as room and number. Re-read whenever it is saved. |
| `--listen ADDR:PORT` | `0.0.0.0:8080` | Where the web pages are served. Use `127.0.0.1:8080` to allow only browsers on this machine. |
| `--port PORT` | `8080` | Just the port, when the address is fine as it is — `--port 9000` serves on every interface at 9000. Overrides the port in `--listen`. |
| `--poll-ms MS` | `250` | How often to read the kiosk saber. |
| `--speed KHZ` | `4000` | Probe speed. Lower it (e.g. `1000`) if long or loose wires cause read errors. |
| `--no-probe` | off | Serve the saved leaderboard without a probe: for rehearsing the screens, or showing final results after the saber is packed away. The pages say **[ OFFLINE BOARD ]** rather than flying a broken uplink. |
| `-h`, `--help` | | Show the options. |

---

# The data file

`leaderboard.json` keeps the latest report parts from every saber, and the
time (with the numbers) of every report each saber has sent — that is where
the winners' times come from. It's written each time something changes, so
it's always up to date.

- **Back it up** by copying it at any time. Or save the JSON feed:
  `curl -o standings.json http://HOST:8080/api/leaderboard`.
- **Show final results** after the event, without the saber:
  `./kiosk-host --no-probe --db leaderboard.json`.
- **It contains attendee handles.** Treat it as event data; it's git-ignored
  in the repo.

## Merging two kiosks

With a kiosk at each of two locations, each kiosk-host keeps its own
`leaderboard.json`. To combine them, fold one into the other:

```sh
./kiosk-host merge leaderboard.json other-site.json --out combined.json
```

Every saber from both files is kept. A saber that reported at both gets both
histories, and the numbers from whichever site heard from it last. Winners
and their **WON** times come out as if one kiosk had seen every report.
Reports on both files (from a file copied between sites earlier) count once,
so merging the same file twice is harmless. The times are each machine's own
clock, so set both clocks right before the event.

Leave off `--out` to rewrite the first file in place; a `.bak-<number>` copy
of it is kept next to it. `--dry-run` only prints the counts. You can list
several files after the first.

**On an installed kiosk,** use `bt5-merge-in`, with the service running:

```sh
sudo bt5-merge-in other-site.json
```

It shows what the merge would do while the board keeps running, asks, then
stops kiosk-host for the few seconds the merge takes and starts it again
(also if the merge fails). No reports are lost meanwhile: the kiosk saber
keeps them and kiosk-host catches up when it starts. The board is backed up
to `leaderboard.json.bak-<number>` first, and each file merged in is kept in
`/var/lib/bt5-kiosk/merged/`. `-n` only previews; `-y` skips the question.
List several files to merge them all at once.

Doing it by hand instead, stop the service first. It holds the board in
memory and would write its own copy back over the merge the next time a
report arrives:

```sh
sudo systemctl stop bt5-kiosk-host
sudo install -o bt5kiosk -m 640 other-site.json /var/lib/bt5-kiosk/
sudo -u bt5kiosk /opt/bt5-kiosk/kiosk-host merge \
    /var/lib/bt5-kiosk/leaderboard.json /var/lib/bt5-kiosk/other-site.json
sudo systemctl start bt5-kiosk-host
```

Run it as `bt5kiosk` (the `sudo -u`), so the service can still write the file
afterwards. From the repo, `tools/merge_leaderboard.sh` does the same thing
and refuses to merge in place while a kiosk-host is running on that machine.

## Starting a fresh leaderboard

Deleting the file isn't enough: the kiosk saber still remembers its last
1024 report parts and hands them back when kiosk-host starts. To clear test
data before the con, on each kiosk machine:

```sh
sudo systemctl start bt5-kiosk-reset
```

It stops kiosk-host, resets the kiosk saber over the probe (which empties its
memory, as a power cycle would), moves `leaderboard.json` aside to
`leaderboard.json.reset-<time>` in `/var/lib/bt5-kiosk`, and starts kiosk-host
again. The screens show an empty board within a few seconds. See what it did
with `journalctl -u bt5-kiosk-reset`.

- If the saber doesn't answer (probe unplugged, saber off), nothing is moved
  and kiosk-host starts again on the old board: fix the probe and rerun it.
- On a machine with `--no-probe` in `KIOSK_HOST_ARGS` it only moves the file.
- By hand, without the service: stop kiosk-host, run
  `./kiosk-host --db leaderboard.json reset`, start kiosk-host.
- It clears the board, not the badges: a test badge that reports again lands
  on the fresh board. Neuralyze test badges before handing them out.

---

# Troubleshooting

When kiosk-host can't reach the saber, it prints the reason followed by
`retrying in 2 s`, and keeps retrying. The web pages stay up and show the
last saved standings, with **[ UPLINK LOST ]** in the corner — so the TV
tells you the kiosk needs attention without anyone watching the terminal.
It goes back to **[ UPLINK OK ]** on its own the moment the saber answers
again.

### `no debug probe found`

The probe isn't plugged in, or this user can't use it. Check the cable, then
check that `69-bt5-debugprobe.rules` is installed
([step 3](#3-install-it-on-the-host-computer)). If running with `sudo` works,
the udev rule is the problem.

### `2 probes attached — pass --probe VID:PID[:SERIAL] to pick one`

Add `--probe 2e8a:000c`. If two debugprobes are attached, add the serial:
`--probe 2e8a:000c:SERIAL` (run `lsusb -v -d 2e8a:000c | grep iSerial` to
see it).

### `failed to attach to the kiosk badge`

Often followed by `Target device did not respond to request`. The probe can't
talk to the saber: check the clip on the dev pins and that the saber has
power. Another program may be holding the probe; stop any `cargo run` or
`probe-rs`. Try `--speed 1000`.

### `no kiosk log in RAM — is this badge running a --features kiosk build?`

The saber is running normal attendee firmware. Reflash it with
[`cargo run --features kiosk,admin`](#1-flash-the-kiosk-saber).

### `kiosk log header vanished`

The saber was reflashed or reset into other firmware while kiosk-host was
reading it. If that was deliberate, carry on; kiosk-host reattaches.

### `warning: N report pages were overwritten before we read them`

The kiosk saber received more than 1024 report parts while kiosk-host wasn't
reading. Those reports are lost; the attendees need to report again. Keep
kiosk-host running during the event.

### `web: cannot listen on 0.0.0.0:8080: Address already in use`

Another kiosk-host is already running (look for it in another terminal), or
another program uses port 8080. Stop it, or start this one with
`--listen 0.0.0.0:8081` and point the browsers at that port.

### The page says UPLINK LOST

Either half of the chain can cause it, and the page doesn't say which — look
at the kiosk-host terminal, or at `/api/status`, to tell them apart.

- **The terminal is printing a probe error** (most often `failed to attach to
  the kiosk badge`, looked up above): kiosk-host is fine and the pages are
  live, but it is not reading the kiosk saber, so nothing new can reach the
  board.
- **The terminal looks healthy**: the browser can't reach kiosk-host. Check
  that kiosk-host is still running, that the browser's `HOST` is right, and
  that port 8080 is open between the machines.

Either way the page recovers on its own within 3 seconds of the problem being
fixed; there is nothing to restart or reload.

### An attendee reported but isn't on the board

- **Did the kiosk saber chime?** If not, the report didn't get through.
  Aim the blade tip straight at the kiosk saber from closer, out of direct
  sunlight, and report again.
- **Is it in UNALIGNED?** A saber that hasn't picked a side, or whose
  faction part didn't arrive, is listed there instead of in a column.
- **Search for the badge id** on the terminal rather than the handle, in
  case the handle is empty or different from what they expect.

### The same saber reports twice in a row, but only the first one chimes

That saber has old firmware. Reflash it from the current code.

### Several attendees show up as the same row, `#0000`

Their sabers were never given badge ids at the production jig; all such
sabers share id `0000`. They need provisioning to appear separately.

### A row shows `[partial]`

Some part of that saber's report never arrived. The row shows what did
arrive. Have the attendee report again, aiming until the screen says
**SENT** (7½ seconds or more; the talk list makes it longer).

### A saber that should have won isn't on the WINNERS panel

Have the attendee report again and watch kiosk-host's output
(`journalctl -fu bt5-kiosk-host`): each line ends with the verdict, `winner`
or the rule lines still missed, such as `(talks 13/14)`. That verdict is
only ever printed there, never served. A saber missing `tracks 0/2` and
`lean 0/12` together has firmware from before winners existed (it doesn't
send those numbers) and needs reflashing. Also check that its last report
arrived whole (no `[partial]`).

### Numbers went down

The saber reported after being wiped (for example, neuralyzed by an
organizer). The board always shows a saber's latest report.
