#!/usr/bin/env python3
"""Park the pointer in the bottom-right corner, a few times, while the kiosk page loads.

Started (as root) by bt5-kiosk-browser.service alongside cage. The TV pages
hide the pointer with cursor: none, but Chromium only applies a page's cursor
on pointer motion, so with a mouse (or a keyboard dongle, or a touch panel
that calls itself a mouse) attached, the arrow sits mid-screen until someone
touches it. This makes the motion for them through a short-lived uinput
pointer: kernel-level, so it works under any compositor. Standard library only.

The pointer is ABSOLUTE (like a VM's tablet pointer) and goes to the far
corner. A relative one-pixel nudge didn't do it on a Pi 4: the compositor's
acceleration shrinks a tiny move to next to nothing. An absolute position
lands exactly, and in the corner the arrow (drawn from its tip) is off the
screen even if the page never gets to hide it.
"""

import fcntl
import os
import struct
import sys
import time

# linux/uinput.h and linux/input-event-codes.h
UI_SET_EVBIT = 0x40045564
UI_SET_KEYBIT = 0x40045565
UI_SET_ABSBIT = 0x40045567
UI_DEV_CREATE = 0x5501
UI_DEV_DESTROY = 0x5502
EV_SYN, EV_KEY, EV_ABS = 0x00, 0x01, 0x03
SYN_REPORT = 0
ABS_X, ABS_Y = 0x00, 0x01
ABS_MAX = 32767
BTN_LEFT = 0x110  # with it, udev tags an ABS_X/Y device a mouse, not a tablet
BUS_VIRTUAL = 0x06

# Seconds between nudges: the page may still be loading at the first.
SCHEDULE = [3, 3, 4, 10, 10, 30]


def event(fd, kind, code, value):
    # struct input_event: struct timeval (two C longs), u16 type, u16 code, s32 value
    os.write(fd, struct.pack("llHHi", 0, 0, kind, code, value))


def nudge():
    fd = os.open("/dev/uinput", os.O_WRONLY | os.O_NONBLOCK)
    try:
        fcntl.ioctl(fd, UI_SET_EVBIT, EV_KEY)
        fcntl.ioctl(fd, UI_SET_EVBIT, EV_ABS)
        fcntl.ioctl(fd, UI_SET_KEYBIT, BTN_LEFT)
        fcntl.ioctl(fd, UI_SET_ABSBIT, ABS_X)
        fcntl.ioctl(fd, UI_SET_ABSBIT, ABS_Y)
        # struct uinput_user_dev: name, input_id, ff_effects_max, then
        # absmax/absmin/absfuzz/absflat[64]; X and Y span 0..ABS_MAX.
        absmax = [0] * 64
        absmax[ABS_X] = absmax[ABS_Y] = ABS_MAX
        os.write(fd, struct.pack("80sHHHHi256i", b"bt5-kiosk pointer nudge",
                                 BUS_VIRTUAL, 0, 0, 1, 0, *absmax, *([0] * 192)))
        fcntl.ioctl(fd, UI_DEV_CREATE)
        try:
            time.sleep(1.5)  # udev, libinput and cage have to find it first
            # Two positions, so there is motion even if the first reads as
            # where a fresh device already is.
            for x in (ABS_MAX - 1, ABS_MAX):
                event(fd, EV_ABS, ABS_X, x)
                event(fd, EV_ABS, ABS_Y, ABS_MAX)
                event(fd, EV_SYN, SYN_REPORT, 0)
                time.sleep(0.05)
            time.sleep(0.2)
        finally:
            fcntl.ioctl(fd, UI_DEV_DESTROY)
    finally:
        os.close(fd)


def main():
    # --now: one nudge straight away, for checking by hand (as root, with the
    # kiosk on screen: the arrow should go).
    schedule = [0] if sys.argv[1:] == ["--now"] else SCHEDULE
    for delay in schedule:
        time.sleep(delay)
        try:
            nudge()
        except OSError as e:
            print(f"nudge-pointer: {e}", file=sys.stderr)
            return 1
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        sys.exit(130)
