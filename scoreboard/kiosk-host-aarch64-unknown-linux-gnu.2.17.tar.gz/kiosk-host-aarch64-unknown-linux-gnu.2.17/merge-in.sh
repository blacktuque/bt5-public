#!/usr/bin/env bash
# Merge other kiosks' leaderboard files into this kiosk's board, with the
# service running:
#
#   sudo bt5-merge-in other-site.json [more.json...]   preview, ask, merge
#   sudo bt5-merge-in -y other-site.json               without asking
#   sudo bt5-merge-in -n other-site.json               preview only
#
# Shows what the merge would do while the board keeps running, then stops
# bt5-kiosk-host for the few seconds the merge takes and starts it again (also
# if the merge fails). Nothing is lost meanwhile: the kiosk saber keeps new
# reports in its memory and kiosk-host catches up when it starts. The board
# is backed up first (leaderboard.json.bak-<unix time>), and each file merged
# in is kept in /var/lib/bt5-kiosk/merged/. Merging the same file again is
# harmless: reports already on the board count once.
#
# Installed by install.sh as /usr/local/bin/bt5-merge-in. See "Merging two
# kiosks" in userguide.md.
set -euo pipefail

prefix=/opt/bt5-kiosk
state=/var/lib/bt5-kiosk
account=bt5kiosk
unit=bt5-kiosk-host.service
board="$state/leaderboard.json"

yes=0
preview=0
files=()
while [[ $# -gt 0 ]]; do
    case "$1" in
        -y|--yes) yes=1; shift ;;
        -n|--dry-run) preview=1; shift ;;
        -h|--help) sed -n '2,18p' "$(realpath "$0")"; exit 0 ;;
        -*) echo "unknown option: $1" >&2; exit 2 ;;
        *) files+=("$1"); shift ;;
    esac
done
[[ ${#files[@]} -gt 0 ]] || { echo "usage: sudo bt5-merge-in [-y|-n] other-site.json [more.json...]" >&2; exit 2; }
[[ $EUID == 0 ]] || { echo "run as root: sudo bt5-merge-in ${files[*]}" >&2; exit 1; }
[[ -f $board ]] || { echo "$board does not exist: nothing to merge into" >&2; exit 1; }

# Copies the service account can read, named for when they came in, so a
# second "leaderboard.json" from another site never lands on this board's.
stamp="$(date +%Y%m%d-%H%M%S)"
incoming="$state/merged"
install -d -o "$account" -g "$account" -m 750 "$incoming"
copies=()
for f in "${files[@]}"; do
    [[ -f $f ]] || { echo "$f: no such file" >&2; exit 1; }
    [[ "$(realpath "$f")" != "$(realpath "$board")" ]] || { echo "$f is this kiosk's own board" >&2; exit 1; }
    copy="$incoming/$stamp-$(basename "$f")"
    install -o "$account" -g "$account" -m 640 "$f" "$copy"
    copies+=("$copy")
done

merge() { sudo -u "$account" "$prefix/kiosk-host" merge "$board" "${copies[@]}" "$@"; }

echo "== preview (the board keeps running)"
if ! merge --dry-run; then
    rm -f "${copies[@]}"
    exit 1
fi
if [[ $preview == 1 ]]; then
    rm -f "${copies[@]}"
    exit 0
fi
if [[ $yes == 0 ]]; then
    read -r -p "Merge now? This pauses the kiosk for a few seconds. [y/N] " answer
    [[ $answer == [yY]* ]] || { rm -f "${copies[@]}"; echo "nothing merged"; exit 0; }
fi

was_running=0
if systemctl is-active --quiet "$unit"; then
    was_running=1
    # Back up even if the merge fails part way.
    trap 'systemctl start "$unit"; echo "== $unit started again"' EXIT
    systemctl stop "$unit"
    echo "== $unit stopped"
fi
echo "== merging"
merge
[[ $was_running == 1 ]] || echo "($unit was not running; start it with: sudo systemctl start $unit)"
echo "merged in: ${copies[*]}"
