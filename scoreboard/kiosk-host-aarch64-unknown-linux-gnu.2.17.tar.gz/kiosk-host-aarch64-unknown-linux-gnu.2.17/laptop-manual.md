# BT5 Kiosk Laptop: Operator Manual

The report kiosk on an Ubuntu laptop with no network. The laptop's own screen
is the **kiosk terminal** (`/?kiosk`), where attendees look themselves up. The
projector shows the **rotating board** (`/?rotate`). Everything runs offline,
locked down so that attendees can't leave the kiosk pages.

On the installed laptop this file is `/opt/bt5-kiosk/laptop-manual.md`. From
the admin terminal, `bt5-kiosk manual` opens it (`q` quits). The general guide
to the kiosk (scoring, winners, the saber side) is `userguide.md` next to it.

---

## Quick card: print this and keep it with the laptop

| To... | Do this |
|---|---|
| **Get out of the kiosk screen** | **Ctrl+Alt+Shift+T**, then log in with the admin password |
| See all the commands | `bt5-kiosk help` |
| Go back to the kiosk | `exit` (or Ctrl+D) closes the admin terminal |
| Show the kiosk, keep the terminal | **Ctrl+Alt+Shift+K** (Ctrl+Alt+Shift+T brings it back) |
| Is everything working? | `bt5-kiosk status` |
| Organizer stats | `bt5-kiosk stats` (Ctrl+W closes them) |
| Change the winner rule | `bt5-kiosk edit winners` |
| Merge another kiosk's board | `bt5-kiosk usb`, then `bt5-kiosk merge /mnt/usb/FILE.json`, then `bt5-kiosk usb off` |
| Fresh board before doors open | `bt5-kiosk reset` |
| Wrong screen on the projector | `bt5-kiosk identify`, then `bt5-kiosk displays` |
| Screens stuck or blank | `bt5-kiosk restart` |
| Plain console | `bt5-kiosk stop` (log in on the text screen), `bt5-kiosk start` to go back |
| **Nothing responds at all** | [Recovery](#recovery-when-the-kiosk-wont-let-you-in): hold Shift or tap Esc at power-on |

Admin account: `______________`   Password: kept by `______________`

---

## Contents

1. [How it fits together](#how-it-fits-together)
2. [Before you go offline](#before-you-go-offline)
3. [Installing](#installing)
4. [Dress rehearsal checklist](#dress-rehearsal-checklist)
5. [During the con](#during-the-con)
6. [Command reference](#command-reference)
7. [Troubleshooting](#troubleshooting)
8. [Recovery: when the kiosk won't let you in](#recovery-when-the-kiosk-wont-let-you-in)
9. [What is locked down, and what isn't](#what-is-locked-down-and-what-isnt)
10. [Files, services and settings](#files-services-and-settings)
11. [Turning it back into a normal laptop](#turning-it-back-into-a-normal-laptop)

---

## How it fits together

```
 kiosk saber ──SWD probe──> kiosk-host (bt5-kiosk-host.service)
                                 │  reads reports, keeps /var/lib/bt5-kiosk/leaderboard.json,
                                 │  serves http://127.0.0.1:8080 to this laptop only
                                 ▼
             screens (bt5-kiosk-browser.service): sway on tty7, account bt5screen
             ├── laptop screen: Chromium, /?kiosk   (keyboard, touchpad and mouse work here)
             ├── projector:     Chromium, /?rotate  (look only: the pointer can't reach it)
             └── admin screen:  a terminal that asks for the admin password first
```

- **Two services.** `bt5-kiosk-host` reads the kiosk saber and serves the
  pages. `bt5-kiosk-browser` runs the screens. Either one can restart without
  the other.
- **Nothing to switch to.** The screens have no desktop behind them: no
  launcher, no taskbar, no window switching. The only way out is the admin
  key combination, and it asks for a password.
- **Projector plugged in late.** If the projector isn't plugged in at boot,
  the board waits hidden behind the kiosk. It moves onto the projector as
  soon as the cable goes in.
- **A closed browser comes back.** If either browser closes or crashes, it
  reopens within a few seconds, once kiosk-host answers.
- **tty1 stays a normal text login.** You get to it by stopping the screens
  (`bt5-kiosk stop`), not by Ctrl+Alt+F-keys: those are off.

---

## Before you go offline

The laptop has no network at the con, so **everything it needs must be
installed while it still has one.** The installer never downloads anything.

1. **Ubuntu 24.04** (desktop or server), fully updated:
   ```sh
   sudo apt update && sudo apt full-upgrade -y
   ```
2. **The kiosk's packages:**
   ```sh
   sudo apt install -y sway foot python3 kbd util-linux nano less
   sudo snap install chromium
   ```
   On Ubuntu, Chromium only comes as a snap: the `snap install` is required
   even if Firefox is already there.
3. **Check nothing is missing.** From the unpacked release folder:
   ```sh
   ./install.sh --laptop --check
   ```
   It lists anything missing, with the command to fix it.
4. **The admin account.** Use the account you install from, or pass
   `--admin NAME` to the installer. It needs:
   - a password you will remember at 2 a.m. (`sudo passwd NAME`);
   - sudo rights (`groups NAME` shows `sudo`).

   Write the name on the [quick card](#quick-card-print-this-and-keep-it-with-the-laptop).
5. **The clock.** Every report and every winner's WON time is stamped with
   this laptop's clock, and there is no internet time at the con. Check the
   date, time and time zone now:
   ```sh
   timedatectl
   sudo timedatectl set-timezone America/Toronto    # if the zone is wrong
   ```
6. **Copy the release** (`kiosk-host-x86_64-unknown-linux-gnu.2.17.tar.gz`)
   onto the laptop, and keep a copy on a USB stick.
7. **Optional: turn off automatic updates,** so nothing half-applies the next
   time it sees a network: `sudo systemctl disable --now unattended-upgrades`.

---

## Installing

Installing needs no network. From the unpacked release folder:

```sh
tar xzf kiosk-host-x86_64-unknown-linux-gnu.2.17.tar.gz
cd kiosk-host-x86_64-unknown-linux-gnu.2.17
sudo ./install.sh --laptop
```

It checks the packages first; if one is missing it stops before changing
anything and prints the command to install it. Then it asks two things.

**Which output is the laptop screen?** It lists the laptop's display outputs
as sway names them, with their cable state:

```
   1) DP-1         disconnected
   2) HDMI-A-1     disconnected
   3) eDP-1        connected     (built-in screen)
```

`eDP-1` (sometimes `LVDS-1`) is the laptop's own screen, which is the
default: press Enter.

**Which goes to the projector?** The recommended answer is `a`: *any external
output*, meaning whichever one is plugged in. That covers HDMI, DisplayPort
and USB-C adapters, which all show up under different names (`HDMI-A-1`,
`DP-1`, `DP-3`...). Pick a number only to tie the board to one port.

Both answers can be changed later with `bt5-kiosk displays`, and
`bt5-kiosk identify` labels each screen with its name.

**It ends with a box that shows the admin keys. Copy them onto the quick
card.** After the reboot, nothing on screen shows them. Then:

```sh
sudo reboot
```

The laptop boots straight into the kiosk: the kiosk terminal on its screen,
the board on the projector.

**What the installer changes:**
- adds the service accounts `bt5kiosk` (the leaderboard) and `bt5screen` (the
  screens), neither with a password;
- installs `/opt/bt5-kiosk`, `/etc/bt5-kiosk/*.toml`, `/etc/default/bt5-kiosk`,
  and the commands `bt5-kiosk` and `bt5-merge-in`;
- installs the probe's udev rule and three services;
- turns off the desktop login screen (GDM), remembering it for uninstall;
- has the power key, suspend key and lid do nothing (from the next boot);
- turns off Ctrl+Alt+Del and the magic SysRq keys;
- adds Chromium lockdown policies, written each time the screens start.

**Upgrading** (a new release): unpack it and run `sudo ./install.sh` again.
It remembers it is a laptop install, keeps your settings, display choice and
data, and never needs the network. Reboot, or run `bt5-kiosk restart` and
`bt5-kiosk restart-host`.

---

## Dress rehearsal checklist

Do this **at least a day before**, with the real projector, the real kiosk
saber and probe, and a spare badge. Every item has caught someone out
before.

**Screens**
- [ ] After boot: the kiosk terminal (`find>` box) is on the laptop, and the
      board (`./leaderboard --live --rotate`) is on the projector.
- [ ] Unplug the projector and plug it back in: the board comes back on it.
- [ ] `bt5-kiosk identify` labels each screen correctly.

**Getting out, and back**
- [ ] **Ctrl+Alt+Shift+T** opens the admin terminal on the laptop screen; the
      projector keeps showing the board.
- [ ] The admin password logs you in; `bt5-kiosk status` shows both services
      `active`.
- [ ] `exit` returns to the kiosk.
- [ ] At the password prompt, Ctrl+C returns to the kiosk.
- [ ] `bt5-kiosk stop` drops to the text login, and `bt5-kiosk start` after
      logging in brings the screens back.

**The leaderboard**
- [ ] `bt5-kiosk status` says *uplink OK*.
- [ ] A test badge's report appears on both screens, and the lookup finds
      it.
- [ ] `bt5-kiosk stats` opens the stats page; Ctrl+W closes it.
- [ ] `bt5-kiosk reset` clears the board (do this last; see below).

**Lockdown**, on the kiosk terminal as an attendee would try it. Nothing
should happen:
- [ ] Ctrl+O, Ctrl+S, Ctrl+P (no file or print dialog).
- [ ] F12, Ctrl+Shift+I, Ctrl+U, and right-click → Inspect (no developer
      tools).
- [ ] Ctrl+N, Ctrl+T, Ctrl+L, Alt+Home (no new window or address bar).
- [ ] Ctrl+Alt+F2, Ctrl+Alt+F3 (no console).
- [ ] Ctrl+W and Alt+F4 (the page is back within a few seconds).
- [ ] A short press of the power button; closing and opening the lid (still
      running).
- [ ] Ctrl+Alt+Del (nothing).

**Recovery**
- [ ] Walk through [Recovery](#recovery-when-the-kiosk-wont-let-you-in) once,
      so you know which key brings up the boot menu on this laptop.

**Before doors open**
- [ ] `bt5-kiosk clock` shows the right time and date.
- [ ] `bt5-kiosk reset` for a clean board, then `bt5-kiosk status` shows 0
      operatives.
- [ ] Neuralyze any test badges that will be handed out: clearing the board
      doesn't clear the badges.

---

## During the con

### The admin terminal

Press **Ctrl+Alt+Shift+T** anywhere. A terminal opens on the laptop screen,
and the projector carries on showing the board. It asks for the admin
account's password. Once you're logged in, you're in an ordinary shell as that
account, and `bt5-kiosk help` lists what it can do.

- `exit` or Ctrl+D closes it and returns to the kiosk.
- **Ctrl+Alt+Shift+K** switches to the kiosk and leaves the terminal open.
  Ctrl+Alt+Shift+T switches back to the same terminal.
- If an attendee finds the keys, they get a password prompt and nothing more.
  Ctrl+C or a wrong password closes it.
- The laptop screen faces the attendees. Don't edit the secret winner rule
  while someone can read over your shoulder.
- Copy and paste in the terminal: Ctrl+Shift+C and Ctrl+Shift+V.
- Bigger text: Ctrl+plus.

Most `bt5-kiosk` commands ask for the same password again the first time
(that is sudo).

### Changing the winner rule, scoring or talk titles

```sh
bt5-kiosk edit winners      # or: scoring, talks
```

This opens nano. Save with **Ctrl+O** then Enter, and quit with **Ctrl+X**.
kiosk-host picks up the change within a few seconds, with no restart. If the
file has a mistake, it keeps the old rule and says why: check with
`bt5-kiosk logs`. `userguide.md` explains every line (*Winners*, *Scoring*).

**Revealing winners later.** Setting `hide_winners = true` in the winners file
keeps the WINNERS panel empty while `bt5-kiosk stats` still counts them. Set
it back to `false` to reveal everyone, each with their real WON time.

### Merging another kiosk's board

Bring the other kiosk's `leaderboard.json` on a USB stick (on that kiosk it
is `/var/lib/bt5-kiosk/leaderboard.json`). Rename it if it helps, e.g.
`hall-b.json`.

```sh
bt5-kiosk usb                              # mounts the stick read-only at /mnt/usb and lists it
bt5-kiosk merge /mnt/usb/hall-b.json       # shows what it would do, asks, then merges
bt5-kiosk usb off                          # then pull the stick
```

- **The screens stay up.** The board pauses for a few seconds while kiosk-host
  restarts. The kiosk saber keeps any report that arrives meanwhile.
- **Merging again is harmless.** Reports already on the board count once, so
  a later copy of the same file just adds what's new.
- **A backup is kept.** The board before the merge is saved as
  `leaderboard.json.bak-<number>`, and every file merged in is kept in
  `/var/lib/bt5-kiosk/merged/`.

### Starting a fresh board

```sh
bt5-kiosk reset
```

Type `RESET` to confirm. This clears the kiosk saber's memory and moves the
board aside (kept as `leaderboard.json.reset-<number>`). Both screens show an
empty board within seconds. If the saber doesn't answer, nothing changes:
check the probe cable and run it again.

### The clock

```sh
bt5-kiosk clock                            # what time the laptop thinks it is
bt5-kiosk clock set "2026-10-03 09:15"     # set it
```

WON times and report times use this clock. Set it before reports arrive:
changing it later doesn't re-date anything already stamped.

### Displays

```sh
bt5-kiosk identify      # a yellow banner on each screen names it, for 20 s
bt5-kiosk displays      # choose again; restarts the screens
```

`displays` and `restart` restart the screens, which also closes the admin
terminal you ran them from. Press Ctrl+Alt+Shift+T again afterwards.

---

## Command reference

Run these from the admin terminal, or from the text console after
`bt5-kiosk stop`.

| Command | What it does |
|---|---|
| `bt5-kiosk help` | the list of commands |
| `bt5-kiosk status` | services, uplink, operatives on the board, displays, clock, keys |
| `bt5-kiosk stats` | the organizer stats page (`/admin`) on the laptop screen; Ctrl+W closes it |
| `bt5-kiosk edit winners` / `scoring` / `talks` | edit a rule file (applies on save) |
| `bt5-kiosk edit settings` | edit `/etc/default/bt5-kiosk` (then `bt5-kiosk restart`) |
| `bt5-kiosk usb` / `usb off` | mount a USB stick read-only at `/mnt/usb` / unmount it |
| `bt5-kiosk merge FILE...` | merge other kiosks' boards (same as `sudo bt5-merge-in`) |
| `bt5-kiosk reset` | fresh board: clears the kiosk saber and moves the board aside |
| `bt5-kiosk displays` | choose the laptop screen and the projector (restarts the screens) |
| `bt5-kiosk identify` | label each screen with its output name and role |
| `bt5-kiosk restart` | restart the screens (closes the admin terminal) |
| `bt5-kiosk restart-host` | restart kiosk-host |
| `bt5-kiosk stop` / `start` | screens off, for the tty1 text login / back on |
| `bt5-kiosk logs` / `logs screens` | recent output of kiosk-host / of the screens |
| `bt5-kiosk clock` / `clock set "..."` | show / set the date and time |
| `bt5-kiosk keys` | the admin key combinations |
| `bt5-kiosk manual` | this manual |

The underlying services, if you need them directly:
`systemctl status bt5-kiosk-host bt5-kiosk-browser`, and
`journalctl -u bt5-kiosk-host -f` to watch reports arrive live.

---

## Troubleshooting

### The projector shows nothing
- **Check the cable end to end, and the projector's input.** The board
  appears within a few seconds of the cable going in.
- **`bt5-kiosk identify`.** If no banner appears on the projector, the laptop
  doesn't see it. Run `bt5-kiosk status`: the projector's output should read
  `connected`.
- **It's connected but unused.** Run `bt5-kiosk displays` and pick that output
  for the projector, or choose `a` (any external).

### The board is on the laptop and the kiosk on the projector
The laptop screen setting is wrong. Run `bt5-kiosk displays` and choose the
`eDP` output as the laptop screen.

### The projector mirrors a text console
The screens are stopped (after `bt5-kiosk stop`, or they failed). Log in on
the laptop and run `bt5-kiosk start`. If they won't start, see *Black
screen* below.

### *UPLINK LOST* on the board
kiosk-host can't reach the kiosk saber.
1. Check the probe's USB cable and the SWD cable to the saber.
2. Check the kiosk saber is on and its batteries are good.
3. `bt5-kiosk logs` shows the exact error.

It goes back to UPLINK OK on its own. No reports are lost while it's down:
the kiosk saber keeps its last 1024 report parts.

### A screen shows "This site can't be reached"
kiosk-host isn't answering.
1. `bt5-kiosk status`, then `bt5-kiosk restart-host`.
2. Once it answers, `bt5-kiosk restart` reloads both screens.

### The admin keys do nothing
- Hold **Ctrl, Alt and Shift** together and press **T**.
- On a laptop keyboard with an Fn layer, use the left-hand Ctrl and Alt.
- Try an external USB keyboard.
- If the kiosk itself doesn't respond to typing either, the screens have
  hung: see [Recovery](#recovery-when-the-kiosk-wont-let-you-in).
- If the keys were changed, they are in `/etc/default/bt5-kiosk`
  (`KIOSK_ADMIN_KEY`).

### The password is refused
- It is the password of the admin account (`KIOSK_ADMIN` in
  `/etc/default/bt5-kiosk`). Check Caps Lock.
- After a wrong password there is a short delay, and the window closes.
- Press Ctrl+Alt+Shift+T to try again.

### "not in the sudoers file" / `bt5-kiosk` commands refused
The admin account isn't in the `sudo` group. Fix it from the
[Recovery](#recovery-when-the-kiosk-wont-let-you-in) console, logged in as
any account with sudo:

```sh
sudo usermod -aG sudo NAME
```

### A black screen after boot, or the laptop sits at a text login
The screens failed to start.
1. Log in at the text login (tty1) as the admin account.
2. Run:
   ```sh
   systemctl status bt5-kiosk-browser
   journalctl -u bt5-kiosk-browser -b --no-pager | tail -40
   ```
3. Common causes:
   - A package removed since install: `./install.sh --laptop --check` from
     the release folder.
   - A typo in `/etc/default/bt5-kiosk`: `bt5-kiosk edit settings`.
4. Then `bt5-kiosk start`.

After five failed starts in a minute, the screens stop retrying, so that the
text login stays put while you fix things. `bt5-kiosk start` tries again.

### Everything on a screen is too big, or too small
sway guesses a zoom for high-resolution screens. To override it, run
`bt5-kiosk edit settings` and add a line such as `KIOSK_PANEL_SCALE="1.25"`
(or `KIOSK_PROJECTOR_SCALE="1"`). `1` means no zoom. Then run
`bt5-kiosk restart`.

### A change to the winner rule didn't take
`bt5-kiosk logs` shows `winners: ... keeping ...` with the reason: usually a
misspelt key or a bad value. Fix the file and save again.

### The whole laptop is frozen
Hold the power button for about 10 seconds, then power it on again. It boots
straight back into the kiosk, and the board is safe: kiosk-host writes it to
disk on every change.

---

## Recovery: when the kiosk won't let you in

Use this if the screens are wedged, the admin keys don't work, or the
password is lost. It boots the laptop once with the screens switched off, to
a normal text login. It needs no network and changes nothing permanent.

1. **Power the laptop on** (or restart it: hold the power button for 10
   seconds, then press it again).
2. **Open the boot menu (GRUB).** Ubuntu hides it by default:
   - **Most laptops (UEFI):** tap **Esc** once, just after the maker's logo.
     Tapping more than once can land at a `grub>` prompt: type `normal` and
     Enter, then tap Esc once.
   - **Older laptops (BIOS):** hold **Shift** from power-on.
3. With **Ubuntu** highlighted, press **e**.
4. Find the line that starts with `linux`. Move to its end (arrow keys, then
   End), and add a space and then:
   ```
   systemd.mask=bt5-kiosk-browser.service
   ```
5. Press **Ctrl+X** (or F10) to boot.
6. The laptop comes up at a **text login** with the screens off. kiosk-host
   still runs and collects reports. Log in as the admin account and fix what
   needs fixing:
   - a forgotten admin password: `sudo passwd NAME` from another sudo
     account, or see below;
   - `journalctl -u bt5-kiosk-browser -b -1` shows the last boot's screen
     errors.
7. `sudo reboot`. The change in step 4 lasted one boot only, so the kiosk is
   back.

**No account's password works:** in step 4 add `systemd.unit=rescue.target`
instead. That asks for the root password, and Ubuntu has none by default.
Then boot the laptop from an Ubuntu USB stick and reset the password from
there (search "reset Ubuntu password from live USB").

---

## What is locked down, and what isn't

**Locked, for anyone at the keyboard:**
- **The browsers.** No address bar, no new windows, no file dialogs, no
  printing, no downloads, no developer tools or view-source, no
  `chrome://` pages, no extensions.
  - They load only `http://127.0.0.1:8080`; everything else is blocked.
  - A closed or crashed browser reopens.
  - These Chromium policies apply to every Chromium on the laptop, yours
    included. Use Firefox for anything else.
- **The session.** No desktop, launcher, terminal shortcut or window
  switching; Ctrl+Alt+F-keys are off. The pointer can't reach the projector.
- **Admin access.** Only through the admin keys, and only with the admin
  password. The screens run as `bt5screen`, which has no password, no shell
  and no sudo. The browsers can't touch the leaderboard's files: those
  belong to `bt5kiosk`.
- **The machine.** The power key (a short press), suspend and hibernate keys,
  the lid, Ctrl+Alt+Del and the SysRq keys do nothing.

**Not locked**, so keep the laptop where staff can see it:
- **Holding the power button** for several seconds cuts power: that is the
  hardware. The kiosk comes back on the next boot with the board intact.
- **The boot menu (GRUB)** lets anyone at the keyboard do the recovery above.
  They still need a password to log in. To close this off, set a GRUB
  password (search "Ubuntu GRUB password").
- **Booting from a USB stick.** Set a BIOS/UEFI password and turn off USB
  boot in the firmware if that matters.
- **Unplugging things.** The projector cable, the probe, the power supply.
- **The laptop screen faces attendees.** Anything you do in the admin
  terminal is visible to whoever stands there.

---

## Files, services and settings

| What | Where |
|---|---|
| The board (all reports) | `/var/lib/bt5-kiosk/leaderboard.json` |
| Backups from merges / resets | `/var/lib/bt5-kiosk/leaderboard.json.bak-*`, `.reset-*` |
| Files merged in | `/var/lib/bt5-kiosk/merged/` |
| Winner rule, scoring, talk titles | `/etc/bt5-kiosk/winners.toml`, `scoring.toml`, `talks.toml` |
| Settings | `/etc/default/bt5-kiosk` |
| Programs, manuals | `/opt/bt5-kiosk/` |
| Commands | `/usr/local/bin/bt5-kiosk`, `/usr/local/bin/bt5-merge-in` |
| Chromium lockdown | `/etc/chromium-browser/policies/managed/bt5-kiosk.json` (rewritten when the screens start) |
| Sway config | `/run/bt5-kiosk-sway.config` (generated from the settings when the screens start) |
| Power/lid settings | `/etc/systemd/logind.conf.d/90-bt5-kiosk.conf` |

| Service | What it does |
|---|---|
| `bt5-kiosk-host` | reads the kiosk saber over the probe, keeps the board, serves the pages on port 8080 |
| `bt5-kiosk-browser` | the screens: sway on tty7 as `bt5screen`, both browsers, the admin terminal |
| `bt5-kiosk-reset` | run once by `bt5-kiosk reset` |

**Settings in `/etc/default/bt5-kiosk`** (`bt5-kiosk edit settings`, then
`bt5-kiosk restart`):

| Setting | Meaning |
|---|---|
| `KIOSK_PAGE` | the laptop screen's page, normally `/?kiosk` |
| `KIOSK_PROJECTOR_PAGE` | the projector's page, normally `/?rotate` |
| `KIOSK_PANEL` | the laptop screen's output, e.g. `eDP-1` |
| `KIOSK_PROJECTOR` | the projector's output, or several (the first plugged in is used) |
| `KIOSK_ADMIN` | the account the admin terminal logs in as |
| `KIOSK_ADMIN_KEY` | the admin terminal's keys, default `Ctrl+Alt+Shift+t` |
| `KIOSK_BACK_KEY` | back to the kiosk, default `Ctrl+Alt+Shift+k` |
| `KIOSK_PANEL_SCALE` | the laptop screen's zoom, e.g. `1`, `1.25`, `2` (unset: sway's own guess) |
| `KIOSK_PROJECTOR_SCALE` | the projector's zoom, likewise |
| `KIOSK_PORT` | the leaderboard's port (default 8080) |
| `KIOSK_HOST_ARGS` | extra kiosk-host options, e.g. `--probe 2e8a:000c:SERIAL` |

---

## Turning it back into a normal laptop

From the release folder:

```sh
sudo ./install.sh --uninstall
sudo reboot
```

This removes the services, the lockdown (power keys, SysRq, Ctrl+Alt+Del,
Chromium policies) and the commands, and turns the desktop login screen back
on. It keeps the board (`/var/lib/bt5-kiosk`), the settings and rule files,
`/opt/bt5-kiosk`, and the two service accounts. Delete those by hand if you
want them gone:

```sh
sudo userdel -r bt5screen
sudo userdel bt5kiosk
```
