#!/usr/bin/env bash
# bt5-kiosk: run the BT5 kiosk laptop from its admin terminal.
# Installed by install.sh --laptop as /usr/local/bin/bt5-kiosk. `bt5-kiosk
# help` lists the commands; the manual is /opt/bt5-kiosk/laptop-manual.md.
set -euo pipefail

prefix=/opt/bt5-kiosk
settings=/etc/default/bt5-kiosk
etc=/etc/bt5-kiosk
screen_user=bt5screen
host_unit=bt5-kiosk-host.service
screens_unit=bt5-kiosk-browser.service
manual="$prefix/laptop-manual.md"

b() { printf '\033[1m%s\033[0m' "$*"; }
say() { printf '\n\033[1m== %s\033[0m\n' "$*"; }
die() { echo "bt5-kiosk: $*" >&2; exit 1; }

# The settings file, as the services see it.
load() {
    KIOSK_PORT=8080 KIOSK_PANEL=eDP-1 KIOSK_PROJECTOR=HDMI-A-1
    KIOSK_ADMIN_KEY=Ctrl+Alt+Shift+t KIOSK_BACK_KEY=Ctrl+Alt+Shift+k
    # shellcheck disable=SC1090
    [[ -r $settings ]] && . "$settings"
}

set_setting() {
    local key="$1" value="$2" tmp
    tmp="$(mktemp)"
    awk -v k="$key" -v v="$value" '
        $0 ~ "^" k "=" { print k "=\"" v "\""; done = 1; next }
        { print }
        END { if (!done) print k "=\"" v "\"" }' "$settings" > "$tmp"
    cat "$tmp" > "$settings"
    rm -f "$tmp"
}

keycap() { local k="$1" last="${1: -1}"; echo "${k%?}${last^^}"; }

need_root() { [[ $EUID == 0 ]] || exec sudo "$0" "$@"; }

# swaymsg into the running kiosk session, as its user.
in_sway() {
    local uid sock
    uid="$(id -u "$screen_user")"
    sock="$(ls /run/user/"$uid"/sway-ipc.*.sock 2>/dev/null | head -1 || true)"
    [[ -n $sock ]] || die "the kiosk screens aren't running (sudo systemctl start $screens_unit)"
    runuser -u "$screen_user" -- env SWAYSOCK="$sock" XDG_RUNTIME_DIR="/run/user/$uid" swaymsg "$@"
}

# The display connectors this laptop has, as sway names them: eDP-1,
# HDMI-A-1, DP-2... with their cable state.
connectors() {
    local d name
    for d in /sys/class/drm/card*-*; do
        [[ -e $d/status ]] || continue
        name="${d##*/}"; name="${name#card*-}"
        [[ $name == Writeback* ]] && continue
        echo "$name $(cat "$d/status")"
    done | sort -u -k1,1
}
internal() { [[ $1 == eDP* || $1 == LVDS* || $1 == DSI* ]]; }

api() {
    python3 - "$KIOSK_PORT" "$1" <<'EOF'
import json, sys, urllib.request
port, what = sys.argv[1], sys.argv[2]
try:
    with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/{what}", timeout=3) as r:
        data = json.load(r)
except Exception as e:
    print(f"not answering ({e.__class__.__name__})"); sys.exit(0)
if what == "status":
    print({"ok": "uplink OK: collecting from the kiosk saber",
           "lost": "UPLINK LOST: no kiosk saber on the probe" + (f" ({data['detail']})" if data.get("detail") else ""),
           "off": "no probe (--no-probe)"}.get(data.get("state"), data.get("state")))
else:
    print(f"{len(data)} operatives on the board, {sum(1 for r in data if r.get('winner'))} shown as winners")
EOF
}

cmd_help() {
    load
    cat <<EOF
$(b "BT5 kiosk laptop") -- run these from the admin terminal ($(keycap "$KIOSK_ADMIN_KEY")).
Most ask for your password once (sudo).

  $(b "bt5-kiosk status")            is everything running? uplink, board, displays, clock
  $(b "bt5-kiosk stats")             open the organizer stats page (/admin) here; Ctrl+W closes it
  $(b "bt5-kiosk edit winners")      edit the winner rule (also: scoring, talks, settings)
  $(b "bt5-kiosk merge FILE...")     merge another kiosk's leaderboard.json (from a USB stick)
  $(b "bt5-kiosk usb")               mount a USB stick at /mnt/usb (and 'usb off' to unmount)
  $(b "bt5-kiosk reset")             fresh leaderboard: clears the board and the kiosk saber
  $(b "bt5-kiosk displays")          choose which output is the laptop screen / the projector *
  $(b "bt5-kiosk identify")          label each screen with its name and role for 20 s
  $(b "bt5-kiosk restart")           restart the screens (both browsers) *
  $(b "bt5-kiosk restart-host")      restart kiosk-host (the probe reader and web server)
  $(b "bt5-kiosk stop")              screens off, for a plain console on tty1 *
  $(b "bt5-kiosk start")             screens back on (from that console)
  $(b "bt5-kiosk logs") [screens]    kiosk-host's recent output (or the screens')
  $(b "bt5-kiosk clock") [set \"YYYY-MM-DD HH:MM\"]   show or set the date and time
  $(b "bt5-kiosk keys")              the admin key combinations
  $(b "bt5-kiosk manual")            the full manual (q quits)

  $(b exit)                        close the admin terminal, back to the kiosk

  * restarts the screens, which closes this terminal too: reopen it with the keys.
EOF
}

cmd_keys() {
    load
    cat <<EOF
  $(b "$(keycap "$KIOSK_ADMIN_KEY")")   admin terminal (asks for ${KIOSK_ADMIN:-the admin}'s password)
  $(b "$(keycap "$KIOSK_BACK_KEY")")   back to the kiosk, leaving the admin terminal open
  exit (or Ctrl+D)        close the admin terminal
Change them with: bt5-kiosk edit settings (KIOSK_ADMIN_KEY, KIOSK_BACK_KEY), then bt5-kiosk restart
EOF
}

cmd_status() {
    load
    say "services"
    for u in "$host_unit" "$screens_unit"; do
        printf '  %-28s %s\n' "$u" "$(systemctl is-active "$u" 2>/dev/null || true)"
    done
    say "leaderboard (http://127.0.0.1:$KIOSK_PORT)"
    echo "  $(api status)"
    echo "  $(api leaderboard)"
    say "displays"
    local name state role
    while read -r name state; do
        role=""
        [[ $name == "$KIOSK_PANEL" ]] && role="laptop screen: /?kiosk"
        [[ " $KIOSK_PROJECTOR " == *" $name "* ]] && role="projector: /?rotate"
        printf '  %-12s %-13s %s\n' "$name" "$state" "$role"
    done < <(connectors)
    say "clock"
    echo "  $(date '+%a %d %b %Y %H:%M:%S %Z')   (every report and WON time uses this)"
    say "admin keys"
    cmd_keys | sed -n '1,2p'
}

cmd_stats() {
    in_sway exec "$prefix/laptop-session stats" >/dev/null
    echo "The stats page is opening on this screen; Ctrl+W closes it."
}

cmd_identify() {
    load
    local outputs ws2 name msg
    outputs="$(in_sway -t get_outputs -r | python3 -c 'import json,sys; print("\n".join(o["name"] for o in json.load(sys.stdin) if o.get("active", True)))')"
    ws2="$(in_sway -t get_workspaces -r | python3 -c 'import json,sys; print(next((w["output"] for w in json.load(sys.stdin) if w["name"] == "2"), ""))')"
    while read -r name; do
        [[ -n $name ]] || continue
        if [[ $name == "$KIOSK_PANEL" ]]; then msg="THIS IS $name -- the LAPTOP SCREEN (kiosk terminal, /?kiosk)"
        elif [[ $name == "$ws2" ]]; then msg="THIS IS $name -- the PROJECTOR (board, /?rotate)"
        else msg="THIS IS $name -- not used by the kiosk"
        fi
        in_sway exec "timeout 20 swaynag -o $name -y overlay -e top -t warning -f 'monospace 18' -m '$msg'" >/dev/null
        echo "  $msg"
    done <<< "$outputs"
    [[ $ws2 != "$KIOSK_PANEL" ]] || echo "  No projector found: the board waits behind the kiosk until one is plugged in."
}

# Pick the laptop screen and the projector. Used by install.sh too.
cmd_displays() {
    load
    local panel="" projector="" yes=0 restart=1
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --panel) panel="$2"; shift 2 ;;
            --projector) projector="$2"; shift 2 ;;
            --yes) yes=1; shift ;;
            --no-restart) restart=0; shift ;;
            *) die "displays: unknown option $1" ;;
        esac
    done
    local names=() states=() name state i
    while read -r name state; do names+=("$name"); states+=("$state"); done < <(connectors)
    [[ ${#names[@]} -gt 0 ]] || die "no display outputs found under /sys/class/drm"
    local externals=()
    for name in "${names[@]}"; do internal "$name" || externals+=("$name"); done
    local default_panel=""
    for name in "${names[@]}"; do if internal "$name"; then default_panel="$name"; break; fi; done
    [[ -n $default_panel ]] || default_panel="${names[0]}"

    if [[ -z $panel || -z $projector ]] && [[ $yes == 0 && -t 0 ]]; then
        echo
        echo "$(b "Display outputs on this laptop") (a projector shows up as 'connected' once its cable is in):"
        for i in "${!names[@]}"; do
            printf '  %2d) %-12s %-13s %s\n' $((i + 1)) "${names[$i]}" "${states[$i]}" \
                "$(internal "${names[$i]}" && echo '(built-in screen)' || true)"
        done
        echo
        if [[ -z $panel ]]; then
            echo "$(b "Which is the LAPTOP SCREEN?") It shows the kiosk terminal (/?kiosk), where attendees look themselves up."
            read -r -p "  number [default: $default_panel]: " i
            if [[ -z $i ]]; then panel="$default_panel"
            elif [[ $i =~ ^[0-9]+$ && $i -ge 1 && $i -le ${#names[@]} ]]; then panel="${names[$((i - 1))]}"
            else die "no output number $i"
            fi
        fi
        if [[ -z $projector ]]; then
            echo
            echo "$(b "Which goes to the PROJECTOR?") It shows the rotating board (/?rotate)."
            echo "  a) any external output: whichever is plugged in (${externals[*]})  <- recommended"
            echo "  or a number from the list above"
            read -r -p "  choice [default: a]: " i
            if [[ -z $i || $i == a || $i == A ]]; then projector="any"
            elif [[ $i =~ ^[0-9]+$ && $i -ge 1 && $i -le ${#names[@]} ]]; then projector="${names[$((i - 1))]}"
            else die "no output number $i"
            fi
        fi
    fi
    [[ -n $panel ]] || panel="$default_panel"
    [[ -n $projector ]] || projector="any"
    if [[ $projector == any ]]; then
        projector=""
        for name in "${externals[@]}"; do [[ $name == "$panel" ]] || projector+="$name "; done
        projector="${projector% }"
    fi
    [[ " ${names[*]} " == *" $panel "* ]] || echo "warning: $panel is not an output on this laptop (have: ${names[*]})" >&2
    [[ " $projector " != *" $panel "* ]] || die "the projector can't be the laptop screen ($panel)"
    [[ -n $projector ]] || echo "warning: no external outputs found; the board will stay hidden behind the kiosk" >&2

    set_setting KIOSK_PANEL "$panel"
    set_setting KIOSK_PROJECTOR "$projector"
    echo
    echo "  laptop screen (/?kiosk):  $(b "$panel")"
    echo "  projector (/?rotate):     $(b "${projector:-none}")$([[ $projector == *" "* ]] && echo "   (the first one plugged in)")"
    echo "  saved in $settings"
    if [[ $restart == 1 ]] && systemctl is-active --quiet "$screens_unit"; then
        systemctl restart "$screens_unit"
        echo "  screens restarted"
    fi
}

cmd_edit() {
    local file
    case "${1:-}" in
        winners|scoring|talks) file="$etc/$1.toml" ;;
        settings) file="$settings" ;;
        *) die "edit what? winners, scoring, talks or settings" ;;
    esac
    "${EDITOR:-nano}" "$file"
    if [[ $1 == settings ]]; then
        echo "Settings take effect on: bt5-kiosk restart (screens) / bt5-kiosk restart-host"
    else
        echo "Saved: kiosk-host picks it up within a few seconds, no restart. Check it took: bt5-kiosk logs"
    fi
}

cmd_usb() {
    local mnt=/mnt/usb dev
    if [[ ${1:-} == off ]]; then
        umount "$mnt" && echo "unmounted $mnt: safe to pull the stick"
        return
    fi
    mountpoint -q "$mnt" && { echo "already mounted at $mnt:"; ls -la "$mnt"; return; }
    # The newest partition on a USB disk (or the disk, if it has none).
    dev="$(lsblk -rpno NAME,TRAN,TYPE | awk '$2 == "usb" { disk = $1 } END { print disk }')"
    [[ -n $dev ]] || die "no USB stick found (lsblk shows none)"
    local part
    part="$(lsblk -rpno NAME,TYPE "$dev" | awk '$2 == "part" { p = $1 } END { print p }')"
    install -d "$mnt"
    mount -o ro "${part:-$dev}" "$mnt"
    echo "mounted ${part:-$dev} read-only at $mnt:"
    ls -la "$mnt"
    echo "e.g.  bt5-kiosk merge $mnt/leaderboard.json    then: bt5-kiosk usb off"
}

cmd_reset() {
    echo "This starts a $(b "fresh leaderboard"): the board is moved aside (kept as"
    echo "leaderboard.json.reset-<time>) and the kiosk saber's memory is cleared."
    read -r -p "Type RESET to go ahead: " answer
    [[ $answer == RESET ]] || { echo "nothing changed"; return; }
    local since
    since="$(date '+%Y-%m-%d %H:%M:%S')"
    systemctl start bt5-kiosk-reset.service || true
    journalctl -u bt5-kiosk-reset.service --since "$since" --no-pager -o cat
}

cmd_clock() {
    if [[ ${1:-} == set ]]; then
        [[ -n ${2:-} ]] || die 'clock set "YYYY-MM-DD HH:MM"'
        timedatectl set-ntp false 2>/dev/null || true
        timedatectl set-time "$2"
    fi
    timedatectl status | sed -n '1,4p'
}

cmd_logs() {
    if [[ ${1:-} == screens ]]; then
        journalctl -u "$screens_unit" -n 60 --no-pager
    else
        journalctl -u "$host_unit" -n 60 --no-pager
    fi
}

case "${1:-help}" in
    help|-h|--help) cmd_help ;;
    keys) cmd_keys ;;
    manual) exec less "$manual" ;;
    status) need_root "$@"; cmd_status ;;
    stats) need_root "$@"; cmd_stats ;;
    identify) need_root "$@"; cmd_identify ;;
    displays) need_root "$@"; shift; cmd_displays "$@" ;;
    edit) need_root "$@"; shift; cmd_edit "$@" ;;
    usb) need_root "$@"; shift; cmd_usb "$@" ;;
    merge) need_root "$@"; shift; exec /usr/local/bin/bt5-merge-in "$@" ;;
    reset) need_root "$@"; cmd_reset ;;
    stop)
        need_root "$@"
        echo "Stopping the screens. The laptop drops to its text login (tty1): log in there."
        echo "The PROJECTOR shows that console too -- unplug it first if the room shouldn't see it."
        echo "Back to the kiosk afterwards: bt5-kiosk start"
        sleep 3
        systemctl stop "$screens_unit"
        ;;
    start) need_root "$@"; systemctl start "$screens_unit"; echo "screens starting (a few seconds)" ;;
    restart) need_root "$@"; systemctl restart "$screens_unit"; echo "screens restarting (a few seconds)" ;;
    restart-host) need_root "$@"; systemctl restart "$host_unit"; echo "kiosk-host restarted"; sleep 2; load; api status ;;
    clock) need_root "$@"; shift; cmd_clock "$@" ;;
    logs) need_root "$@"; shift; cmd_logs "$@" ;;
    *) echo "unknown command: $1" >&2; cmd_help; exit 2 ;;
esac
