#!/usr/bin/env bash
# Turn this machine (a Raspberry Pi, or any Debian-family Linux with systemd)
# into a BT5 kiosk: on boot, kiosk-host starts collecting from the probe and
# a full-screen browser shows the leaderboard on the attached display.
#
#   sudo ./install.sh                 install or upgrade; screen shows /?rotate
#                                     (/pi?rotate on a Raspberry Pi)
#   sudo ./install.sh --page /?kiosk  ...or the attendee terminal (sets KIOSK_PAGE)
#   sudo ./install.sh --headless      kiosk-host service only, no screen
#   sudo ./install.sh --laptop        Ubuntu laptop: /?kiosk on its own screen,
#                                     /?rotate on the projector, locked down,
#                                     no network needed (see laptop-manual.md)
#   sudo ./install.sh --laptop --check   only check the laptop's packages
#   sudo ./install.sh --uninstall     remove the services (data and config kept)
#
# Run it from the unpacked release folder. Except with --laptop, it installs
# cage and Chromium with apt if they are missing. It disables the desktop
# login screen if there is one (--uninstall turns it back on). Settings:
# /etc/default/bt5-kiosk; winner rule: /etc/bt5-kiosk/winners.toml; scoring:
# /etc/bt5-kiosk/scoring.toml; talk titles: /etc/bt5-kiosk/talks.toml.
#
# --laptop also takes --panel OUTPUT, --projector OUTPUT|any and --admin USER
# to skip those questions. An upgrade of a laptop install stays a laptop one.
set -euo pipefail
self="$(realpath "$0")"
cd "$(dirname "$self")"

prefix=/opt/bt5-kiosk
state=/var/lib/bt5-kiosk
account=bt5kiosk
screen_account=bt5screen
units=/etc/systemd/system
settings=/etc/default/bt5-kiosk
invocation="$0 $*"

page=""
headless=0
laptop=0
check=0
uninstall=0
panel=""
projector=""
admin=""
while [[ $# -gt 0 ]]; do
    case "$1" in
        --page) page="$2"; shift 2 ;;
        --headless) headless=1; shift ;;
        --laptop) laptop=1; shift ;;
        --check) check=1; shift ;;
        --panel) panel="$2"; shift 2 ;;
        --projector) projector="$2"; shift 2 ;;
        --admin) admin="$2"; shift 2 ;;
        --uninstall) uninstall=1; shift ;;
        -h|--help) sed -n '2,23p' "$self"; exit 0 ;;
        *) echo "unknown argument: $1" >&2; exit 2 ;;
    esac
done

say() { printf '\n== %s\n' "$*"; }

# Everything the laptop mode runs, and where it comes from. The laptop has
# no network at the con, so nothing is installed from here: these must be
# there before the installer is run (see laptop-manual.md, "Before you go
# offline").
laptop_missing() {
    local missing=()
    for c in sway swaymsg swaynag foot; do type -P "$c" >/dev/null || missing+=("$c"); done
    [[ -x /snap/bin/chromium ]] || type -P chromium >/dev/null || missing+=(chromium)
    for c in python3 chvt runuser lsblk nano less; do type -P "$c" >/dev/null || missing+=("$c"); done
    echo "${missing[*]}"
}
laptop_prereqs_help() {
    cat <<'EOF'
While the laptop still has a network connection, run:

    sudo apt update
    sudo apt install -y sway foot python3 kbd util-linux nano less
    sudo snap install chromium

then run this installer again. It needs no network itself.
EOF
}

if [[ $laptop == 1 && $check == 1 ]]; then
    missing="$(laptop_missing)"
    if [[ -n $missing ]]; then
        echo "Missing: $missing"
        echo
        laptop_prereqs_help
        exit 1
    fi
    echo "Everything the laptop kiosk needs is installed."
    exit 0
fi
[[ $EUID == 0 ]] || { echo "run as root: sudo $invocation" >&2; exit 1; }

# The desktop login screen and the kiosk would fight over the display: turn
# it off while the kiosk owns the screen, and remember which one it was.
restore_display_manager() {
    if [[ -f $state/display-manager ]]; then
        local dm
        dm="$(cat "$state/display-manager")"
        say "re-enabling $dm"
        systemctl enable "$dm"
        rm -f "$state/display-manager"
    fi
}

# The laptop's lockdown outside the browser: no suspend or power-off from
# its keys and lid, no Ctrl+Alt+Del reboot, no magic SysRq.
laptop_system_files=(
    /etc/systemd/logind.conf.d/90-bt5-kiosk.conf
    /etc/sysctl.d/90-bt5-kiosk.conf
    /etc/chromium-browser/policies/managed/bt5-kiosk.json
    /etc/chromium/policies/managed/bt5-kiosk.json
    /var/snap/chromium/current/policies/managed/bt5-kiosk.json
)

if [[ $uninstall == 1 ]]; then
    say "removing the kiosk services"
    systemctl disable --now bt5-kiosk-browser.service bt5-kiosk-host.service 2>/dev/null || true
    rm -f "$units/bt5-kiosk-browser.service" "$units/bt5-kiosk-host.service" "$units/bt5-kiosk-reset.service" \
        /etc/pam.d/bt5-kiosk /etc/udev/rules.d/69-bt5-debugprobe.rules /usr/local/bin/bt5-merge-in \
        /usr/local/bin/bt5-kiosk "${laptop_system_files[@]}"
    if [[ -f $state/laptop ]]; then
        systemctl unmask ctrl-alt-del.target 2>/dev/null || true
        sysctl -q --system >/dev/null 2>&1 || true
        rm -f "$state/laptop"
    fi
    systemctl daemon-reload
    restore_display_manager
    echo
    echo "Kept: $state (leaderboard.json), $settings, /etc/bt5-kiosk, $prefix, users $account/$screen_account."
    echo "Reboot to get the normal console or desktop back."
    exit 0
fi

# An upgrade of a laptop install stays one, flag or not: offline, the other
# mode's apt install would fail half way.
if [[ $laptop == 0 && $headless == 0 && -f $state/laptop ]]; then
    echo "This machine was installed with --laptop: upgrading it as one."
    laptop=1
fi
[[ $laptop == 0 || $headless == 0 ]] || { echo "--laptop and --headless don't mix" >&2; exit 2; }

./kiosk-host --help >/dev/null 2>&1 || {
    echo "./kiosk-host does not run on this machine ($(uname -m)). Wrong tarball?" >&2
    echo "A Raspberry Pi with 64-bit Pi OS needs kiosk-host-aarch64-*.tar.gz." >&2
    exit 1
}

if [[ $laptop == 1 ]]; then
    # All checks before the first change, so a missing package leaves the
    # machine as it was.
    say "checking the laptop's packages"
    missing="$(laptop_missing)"
    if [[ -n $missing ]]; then
        echo "Missing: $missing"
        echo
        laptop_prereqs_help
        exit 1
    fi
    echo "all there"
    admin="${admin:-${SUDO_USER:-}}"
    if [[ -z $admin || $admin == root ]]; then
        read -r -p "Admin account (logs in from the admin terminal; needs a password and sudo): " admin
    fi
    id "$admin" >/dev/null 2>&1 || { echo "no such user: $admin" >&2; exit 1; }
    if [[ "$(passwd -S "$admin" | awk '{print $2}')" != P ]]; then
        echo "$admin has no usable password: the admin terminal would never let you in." >&2
        echo "Set one first: sudo passwd $admin" >&2
        exit 1
    fi
    id -nG "$admin" | grep -qwE 'sudo|admin|wheel' ||
        echo "warning: $admin is not in the sudo group; bt5-kiosk commands will be refused." >&2
fi

browser=""
if [[ $headless == 0 && $laptop == 0 ]]; then
    browser="$(type -P chromium || type -P chromium-browser || true)"
    if [[ -z $browser ]] || ! type -P cage >/dev/null; then
        say "installing cage and Chromium"
        apt-get update
        chromium_pkg=chromium
        apt-cache policy chromium 2>/dev/null | grep -q 'Candidate: [0-9]' ||
            chromium_pkg=chromium-browser
        DEBIAN_FRONTEND=noninteractive apt-get install -y cage "$chromium_pkg"
        browser="$(type -P chromium || type -P chromium-browser)"
    fi
    # nudge-pointer.py, which keeps the pointer off the TV pages.
    type -P python3 >/dev/null || DEBIAN_FRONTEND=noninteractive apt-get install -y python3
fi

say "account $account and $state"
if ! id "$account" >/dev/null 2>&1; then
    useradd --system --user-group --home-dir "$state" --shell /usr/sbin/nologin "$account"
fi
# plugdev: the probe (see the udev rule). The rest: the screen, keyboard and
# mouse for cage (the laptop's screens run as their own account, below).
for g in plugdev video render input; do
    if getent group "$g" >/dev/null; then usermod -aG "$g" "$account"; fi
done
install -d -o "$account" -g "$account" -m 750 "$state"
# Remembered from here on, so a rerun without --laptop (an upgrade, or a
# retry after this one stops part way) stays a laptop install.
[[ $laptop == 0 ]] || touch "$state/laptop"

if [[ $laptop == 1 ]]; then
    say "account $screen_account (runs the screens)"
    # Under /home: the Chromium snap refuses a home anywhere else. No
    # password and no shell: nothing logs in as it.
    if ! id "$screen_account" >/dev/null 2>&1; then
        useradd --system --user-group --create-home --home-dir "/home/$screen_account" \
            --shell /usr/sbin/nologin "$screen_account"
    fi
    for g in video render input; do
        if getent group "$g" >/dev/null; then usermod -aG "$g" "$screen_account"; fi
    done
fi

say "kiosk-host to $prefix"
install -D -m 755 kiosk-host "$prefix/kiosk-host"
install -m 644 userguide.md "$prefix/userguide.md"
install -m 755 nudge-pointer.py "$prefix/nudge-pointer.py"
install -m 755 merge-in.sh "$prefix/merge-in"
ln -sf "$prefix/merge-in" /usr/local/bin/bt5-merge-in
if [[ $laptop == 1 ]]; then
    install -m 755 laptop/session.sh "$prefix/laptop-session"
    install -m 755 laptop/bt5-kiosk.sh "$prefix/bt5-kiosk"
    install -m 644 laptop-manual.md "$prefix/laptop-manual.md"
    ln -sf "$prefix/bt5-kiosk" /usr/local/bin/bt5-kiosk
fi
# Earlier tries at hiding the pointer.
rm -rf "$prefix/cursors" "$prefix/kiosk-browser.sh"

say "probe access (udev)"
install -m 644 69-bt5-debugprobe.rules /etc/udev/rules.d/
udevadm control --reload-rules
udevadm trigger --subsystem-match=usb

say "settings in $settings"
if [[ ! -f $settings ]]; then
    install -m 644 bt5-kiosk.default "$settings"
    # A Pi flickers on the full page's animation and blur; /pi is the
    # lite layout. Only for a fresh file: an edited one is left alone.
    if [[ -z $page && $laptop == 0 ]] && grep -qa "Raspberry Pi" /proc/device-tree/model 2>/dev/null; then
        page="/pi?rotate"
    fi
else
    echo "kept the existing file"
fi
# KEY=value, replaced where the file has it, appended where it doesn't.
set_setting() {
    local tmp
    tmp="$(mktemp)"
    awk -v k="$1" -v v="$2" '
        $0 ~ "^" k "=" { print k "=\"" v "\""; done = 1; next }
        { print }
        END { if (!done) print k "=\"" v "\"" }' "$settings" > "$tmp"
    cat "$tmp" > "$settings"
    rm -f "$tmp"
}
has_setting() { grep -q "^$1=" "$settings"; }
if [[ $laptop == 1 ]]; then
    # The laptop's own screen is the attendee terminal; the projector the
    # rotating board. Only set when new, so an operator's choice survives.
    # No projector page yet means the file has never been set up for a
    # laptop (fresh, or from a Pi-style install): its page becomes /?kiosk.
    if ! has_setting KIOSK_PROJECTOR_PAGE; then
        set_setting KIOSK_PAGE "/?kiosk"
        set_setting KIOSK_PROJECTOR_PAGE "/?rotate"
    fi
    has_setting KIOSK_ADMIN_KEY || set_setting KIOSK_ADMIN_KEY "Ctrl+Alt+Shift+t"
    has_setting KIOSK_BACK_KEY || set_setting KIOSK_BACK_KEY "Ctrl+Alt+Shift+k"
    set_setting KIOSK_ADMIN "$admin"
    [[ -z $page ]] || set_setting KIOSK_PAGE "$page"
elif [[ -n $page ]]; then
    set_setting KIOSK_PAGE "$page"
fi
grep -E '^KIOSK_[A-Z_]+=' "$settings"

if [[ $laptop == 1 ]]; then
    say "displays: which output is which"
    args=(--no-restart)
    [[ -z $panel ]] || args+=(--panel "$panel")
    [[ -z $projector ]] || args+=(--projector "$projector")
    # On an upgrade, keep the choice already made unless asked again.
    if [[ -z $panel && -z $projector ]] && has_setting KIOSK_PANEL && has_setting KIOSK_PROJECTOR; then
        echo "kept: laptop screen $(sed -n 's/^KIOSK_PANEL=//p' "$settings"), projector $(sed -n 's/^KIOSK_PROJECTOR=//p' "$settings")"
        echo "(change with: sudo bt5-kiosk displays)"
    else
        "$prefix/bt5-kiosk" displays "${args[@]}"
    fi
fi

say "winner rule in /etc/bt5-kiosk/winners.toml"
# Like the settings: installed once, and an operator's edits survive upgrades.
if [[ ! -f /etc/bt5-kiosk/winners.toml ]]; then
    install -D -m 644 winners.toml /etc/bt5-kiosk/winners.toml
else
    echo "kept the existing file"
fi

say "scoring in /etc/bt5-kiosk/scoring.toml"
if [[ ! -f /etc/bt5-kiosk/scoring.toml ]]; then
    install -D -m 644 scoring.toml /etc/bt5-kiosk/scoring.toml
else
    echo "kept the existing file"
fi

say "talk titles in /etc/bt5-kiosk/talks.toml"
if [[ ! -f /etc/bt5-kiosk/talks.toml ]]; then
    install -D -m 644 talks.toml /etc/bt5-kiosk/talks.toml
else
    echo "kept the existing file"
fi

say "systemd services"
install -m 644 bt5-kiosk-host.service bt5-kiosk-reset.service "$units/"
if [[ $headless == 0 ]]; then
    # A login session on seat0 for the screen; nothing here asks for a password.
    cat > /etc/pam.d/bt5-kiosk <<'EOF'
auth     required pam_unix.so nullok
account  required pam_unix.so
session  required pam_unix.so
session  required pam_systemd.so
EOF
    if [[ $laptop == 1 ]]; then
        install -m 644 laptop/bt5-kiosk-laptop.service "$units/bt5-kiosk-browser.service"
    else
        sed "s|@BROWSER@|$browser|" bt5-kiosk-browser.service > "$units/bt5-kiosk-browser.service"
    fi
fi

if [[ $laptop == 1 ]]; then
    say "laptop lockdown"
    install -d /etc/systemd/logind.conf.d
    cat > /etc/systemd/logind.conf.d/90-bt5-kiosk.conf <<'EOF'
# BT5 kiosk laptop: an attendee at the keyboard can't suspend or power it off.
# (Holding the power button for several seconds still cuts power: that is
# the hardware, not this.) Removed by install.sh --uninstall.
[Login]
HandlePowerKey=ignore
HandlePowerKeyLongPress=ignore
HandleRebootKey=ignore
HandleSuspendKey=ignore
HandleHibernateKey=ignore
HandleLidSwitch=ignore
HandleLidSwitchExternalPower=ignore
HandleLidSwitchDocked=ignore
IdleAction=ignore
EOF
    install -d /etc/sysctl.d
    cat > /etc/sysctl.d/90-bt5-kiosk.conf <<'EOF'
# BT5 kiosk laptop: no magic SysRq (Alt+PrtSc+B would reboot it).
kernel.sysrq = 0
EOF
    sysctl -q -w kernel.sysrq=0
    systemctl mask ctrl-alt-del.target >/dev/null
    echo "power/suspend keys and lid ignored (after reboot), Ctrl+Alt+Del and SysRq off"
fi

systemctl daemon-reload
systemctl enable bt5-kiosk-host.service
# Restart, not just start: an upgrade must pick up the new binary.
systemctl restart bt5-kiosk-host.service

if [[ $headless == 0 ]]; then
    systemctl enable bt5-kiosk-browser.service
    dm_unit="$(readlink -f "$units/display-manager.service" 2>/dev/null || true)"
    if [[ -n $dm_unit && -e $dm_unit ]]; then
        dm="$(basename "$dm_unit")"
        say "disabling the desktop login screen ($dm)"
        echo "$dm" > "$state/display-manager"
        systemctl disable "$dm"
    fi
else
    systemctl disable --now bt5-kiosk-browser.service 2>/dev/null || true
    rm -f "$units/bt5-kiosk-browser.service" /etc/pam.d/bt5-kiosk
    systemctl daemon-reload
    restore_display_manager
fi

port="$(sed -n 's/^KIOSK_PORT=//p' "$settings" | tr -d '"')"
echo
if [[ $laptop == 1 ]]; then
    # shellcheck disable=SC1090
    . "$settings"
    keycap() { local k="$1" last="${1: -1}"; echo "${k%?}${last^^}"; }
    cat <<EOF
======================================================================
 BT5 KIOSK LAPTOP -- installed.  Reboot to start it:  sudo reboot
======================================================================
 Laptop screen ($KIOSK_PANEL): the kiosk terminal, /?kiosk
 Projector ($KIOSK_PROJECTOR): the board, /?rotate

 GETTING OUT OF THE KIOSK SCREEN
   $(keycap "$KIOSK_ADMIN_KEY")    admin terminal: log in as $KIOSK_ADMIN,
                         then type:  bt5-kiosk help
   exit  (or Ctrl+D)     close it, back to the kiosk
   $(keycap "$KIOSK_BACK_KEY")    show the kiosk, the terminal stays open

 If the screens won't come up at all: "Recovery" in
 $prefix/laptop-manual.md (boots with the kiosk switched off).
======================================================================
EOF
    echo "Write the keys down now. After the reboot nothing on screen shows them."
else
    echo "kiosk-host is running:  systemctl status bt5-kiosk-host"
    echo "                        journalctl -fu bt5-kiosk-host"
    echo "fresh leaderboard:      sudo systemctl start bt5-kiosk-reset"
    echo "merge another kiosk:    sudo bt5-merge-in other-site.json"
    for ip in $(hostname -I 2>/dev/null); do
        [[ $ip == *:* ]] || echo "leaderboard:            http://$ip:$port/?rotate"
    done
    if [[ $headless == 0 ]]; then
        echo
        echo "Reboot to start the kiosk screen:  sudo reboot"
        echo "(It takes over the console on tty1, so it isn't started from here.)"
    fi
fi
